"""
HolyOS v1.0 - Micro Linux distribution running inside HolyCMD
Complete implementation in single file.
"""

import os
import sys
import shutil
import subprocess
import json
import yaml
import tempfile
import tarfile
import hashlib
import time
import threading
import shlex
import platform
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
import zipfile
import requests
import uuid
import stat

# ==================== KONFIGURACJA ŚCIEŻEK ====================
HOLYOS_ROOT = Path.home() / ".holycmd" / "holyos"
HOLYOS_IMAGES = HOLYOS_ROOT / "images"
HOLYOS_SNAPSHOTS = HOLYOS_ROOT / "snapshots"
HOLYOS_PACKAGES = HOLYOS_ROOT / "packages"
HOLYOS_CONFIG_FILE = HOLYOS_ROOT / "holyos.yaml"
HOLYOS_BOOT_FILE = HOLYOS_ROOT / "boot.lock"
HOLYOS_LOG_FILE = HOLYOS_ROOT / "holyos.log"

# ==================== KLASA HOLYOS ====================
class HolyOS:
    """Main HolyOS system"""
    
    def __init__(self):
        self.setup_directories()
        self.load_config()
        self.current_image = None
        self.boot_pid = None
        self.log_file = None
        self.setup_logging()
    
    def setup_directories(self):
        """Create HolyOS directory structure"""
        dirs = [
            HOLYOS_ROOT,
            HOLYOS_IMAGES,
            HOLYOS_SNAPSHOTS,
            HOLYOS_PACKAGES,
            HOLYOS_IMAGES / "base",
            HOLYOS_IMAGES / "custom",
            HOLYOS_SNAPSHOTS / "daily",
            HOLYOS_SNAPSHOTS / "manual",
            HOLYOS_PACKAGES / "core",
            HOLYOS_PACKAGES / "net",
            HOLYOS_PACKAGES / "dev",
            HOLYOS_PACKAGES / "gui",
            HOLYOS_PACKAGES / "games"
        ]
        
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
    
    def setup_logging(self):
        """Setup logging system"""
        self.log_file = open(HOLYOS_LOG_FILE, 'a', encoding='utf-8')
    
    def log(self, message: str, level: str = "INFO"):
        """Log message to file and console"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] [{level}] {message}"
        
        # Log to file
        if self.log_file:
            self.log_file.write(log_line + "\n")
            self.log_file.flush()
        
        # Log to console with colors
        colors = {
            "INFO": "\033[92m",    # Green
            "WARN": "\033[93m",    # Yellow
            "ERROR": "\033[91m",   # Red
            "DEBUG": "\033[96m",   # Cyan
        }
        
        color = colors.get(level, "\033[0m")
        print(f"{color}[HolyOS] {message}\033[0m")
    
    def load_config(self):
        """Load or create HolyOS configuration"""
        default_config = {
            "system": {
                "name": "HolyOS",
                "version": "1.0.0",
                "arch": platform.machine(),
                "boot_method": "chroot",  # chroot, container, proot
                "default_image": "base",
                "auto_snapshot": True,
                "snapshot_retention": 7  # days
            },
            "packages": {
                "core": ["bash", "coreutils", "findutils", "grep", "sed", "awk", "vim-tiny"],
                "net": ["curl", "wget", "ssh", "ping", "net-tools"],
                "dev": ["python3", "git", "gcc", "make", "nano"],
                "gui": ["fbterm", "fbi", "mpv"],
                "games": ["ninvaders", "nethack", "bsdgames"]
            },
            "repositories": {
                "main": "https://raw.githubusercontent.com/D3vUserName/HolyOS-packages/main/",
                "extra": "https://holyos.mirror/pkg/"
            },
            "network": {
                "host_network": True,
                "dns": ["8.8.8.8", "1.1.1.1"],
                "proxy": None
            },
            "storage": {
                "image_size": "2GB",
                "snapshot_compression": True,
                "backup_location": str(HOLYOS_SNAPSHOTS)
            }
        }
        
        if not HOLYOS_CONFIG_FILE.exists():
            self.config = default_config
            self.save_config()
        else:
            try:
                with open(HOLYOS_CONFIG_FILE, 'r', encoding='utf-8') as f:
                    self.config = yaml.safe_load(f)
                # Merge with defaults for missing keys
                for key, value in default_config.items():
                    if key not in self.config:
                        self.config[key] = value
            except Exception as e:
                self.log(f"Error loading config: {e}, using defaults", "ERROR")
                self.config = default_config
        
        self.log(f"Config loaded: {self.config['system']['name']} v{self.config['system']['version']}")
    
    def save_config(self):
        """Save HolyOS configuration"""
        try:
            with open(HOLYOS_CONFIG_FILE, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False)
            self.log("Configuration saved")
        except Exception as e:
            self.log(f"Error saving config: {e}", "ERROR")
    
    # ==================== SYSTEM OPERATIONS ====================
    
    def boot(self, image_name: str = None, method: str = None) -> bool:
        """Boot HolyOS image"""
        try:
            if self.is_running():
                self.log("HolyOS is already running!", "WARN")
                return False
            
            image_name = image_name or self.config["system"]["default_image"]
            method = method or self.config["system"]["boot_method"]
            
            self.log(f"Booting HolyOS image: {image_name} using {method}")
            
            # Check if image exists
            image_path = HOLYOS_IMAGES / image_name
            if not image_path.exists():
                self.log(f"Image {image_name} not found. Creating...", "WARN")
                self.create_image(image_name)
            
            # Create boot lock file
            with open(HOLYOS_BOOT_FILE, 'w') as f:
                f.write(str(os.getpid()))
            
            self.current_image = image_name
            
            # Start boot process based on method
            if method == "chroot":
                success = self.boot_chroot(image_path)
            elif method == "proot":
                success = self.boot_proot(image_path)
            elif method == "container":
                success = self.boot_container(image_path)
            else:
                self.log(f"Unknown boot method: {method}", "ERROR")
                return False
            
            if success:
                self.log(f"HolyOS {image_name} booted successfully!")
                # Start background services
                self.start_services()
                return True
            else:
                self.log("Boot failed!", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"Boot error: {e}", "ERROR")
            return False
    
    def boot_chroot(self, image_path: Path) -> bool:
        """Boot using chroot (requires root)"""
        self.log("Using chroot boot method...")
        
        try:
            # Mount necessary filesystems
            mounts = [
                ("/proc", "/proc"),
                ("/sys", "/sys"),
                ("/dev", "/dev"),
                ("/dev/pts", "/dev/pts"),
                ("/run", "/run"),
            ]
            
            for src, dst in mounts:
                dst_path = image_path / dst.lstrip('/')
                dst_path.mkdir(parents=True, exist_ok=True)
                subprocess.run(["mount", "--bind", src, str(dst_path)], 
                             check=False, capture_output=True)
            
            # Start shell in chroot
            cmd = ["chroot", str(image_path), "/bin/bash", "--login"]
            self.boot_pid = subprocess.Popen(cmd).pid
            
            return True
            
        except Exception as e:
            self.log(f"Chroot boot failed: {e}", "ERROR")
            return False
    
    def boot_proot(self, image_path: Path) -> bool:
        """Boot using PRoot (no root required)"""
        self.log("Using PRoot boot method...")
        
        try:
            # Check if proot is installed
            proot_path = shutil.which("proot")
            if not proot_path:
                self.log("PRoot not found. Installing...", "WARN")
                self.install_proot()
                proot_path = shutil.which("proot")
            
            # Build proot command
            cmd = [
                proot_path,
                "-S", str(image_path),
                "-w", "/root",
                "-b", "/proc",
                "-b", "/sys",
                "-b", "/dev",
                "/bin/bash", "--login"
            ]
            
            self.boot_pid = subprocess.Popen(cmd).pid
            return True
            
        except Exception as e:
            self.log(f"PRoot boot failed: {e}", "ERROR")
            return False
    
    def boot_container(self, image_path: Path) -> bool:
        """Boot using systemd-nspawn container"""
        self.log("Using container boot method...")
        
        try:
            cmd = [
                "systemd-nspawn",
                "-D", str(image_path),
                "--boot",
                "--network-veth",
                "--bind=/tmp"
            ]
            
            self.boot_pid = subprocess.Popen(cmd).pid
            return True
            
        except Exception as e:
            self.log(f"Container boot failed: {e}", "ERROR")
            return False
    
    def install_proot(self):
        """Install PRoot if not available"""
        self.log("Installing PRoot...")
        
        # Try to download and compile proot
        try:
            proot_url = "https://github.com/proot-me/proot-static-build/raw/master/static/proot-x86_64"
            response = requests.get(proot_url, stream=True)
            
            proot_path = HOLYOS_ROOT / "bin" / "proot"
            proot_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(proot_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Make executable
            proot_path.chmod(0o755)
            
            # Add to PATH
            bin_dir = HOLYOS_ROOT / "bin"
            os.environ["PATH"] = str(bin_dir) + ":" + os.environ.get("PATH", "")
            
            self.log("PRoot installed successfully")
            
        except Exception as e:
            self.log(f"Failed to install PRoot: {e}", "ERROR")
    
    def shutdown(self, force: bool = False) -> bool:
        """Shutdown HolyOS"""
        try:
            if not self.is_running():
                self.log("HolyOS is not running", "WARN")
                return True
            
            self.log("Shutting down HolyOS...")
            
            # Stop background services
            self.stop_services()
            
            # Kill boot process
            if self.boot_pid:
                import signal
                os.kill(self.boot_pid, signal.SIGTERM)
                if force:
                    time.sleep(2)
                    os.kill(self.boot_pid, signal.SIGKILL)
            
            # Cleanup mount points
            self.cleanup_mounts()
            
            # Remove boot lock
            if HOLYOS_BOOT_FILE.exists():
                HOLYOS_BOOT_FILE.unlink()
            
            self.current_image = None
            self.boot_pid = None
            
            self.log("HolyOS shutdown complete")
            return True
            
        except Exception as e:
            self.log(f"Shutdown error: {e}", "ERROR")
            return False
    
    def is_running(self) -> bool:
        """Check if HolyOS is running"""
        if HOLYOS_BOOT_FILE.exists():
            try:
                with open(HOLYOS_BOOT_FILE, 'r') as f:
                    pid = int(f.read().strip())
                # Check if process exists
                os.kill(pid, 0)
                return True
            except:
                # Process doesn't exist, clean up lock file
                if HOLYOS_BOOT_FILE.exists():
                    HOLYOS_BOOT_FILE.unlink()
                return False
        return False
    
    def cleanup_mounts(self):
        """Cleanup mounted filesystems"""
        try:
            # Unmount chroot mounts
            for mount_point in ["/proc", "/sys", "/dev", "/dev/pts", "/run"]:
                mount_path = HOLYOS_IMAGES / self.current_image / mount_point.lstrip('/')
                if mount_path.exists():
                    subprocess.run(["umount", "-l", str(mount_path)], 
                                 check=False, capture_output=True)
        except Exception as e:
            self.log(f"Cleanup error: {e}", "WARN")
    
    def start_services(self):
        """Start HolyOS background services"""
        self.log("Starting HolyOS services...")
        
        # Start logging service
        threading.Thread(target=self.log_service, daemon=True).start()
        
        # Start network service if enabled
        if self.config["network"]["host_network"]:
            threading.Thread(target=self.network_service, daemon=True).start()
        
        # Start auto-snapshot service
        if self.config["system"]["auto_snapshot"]:
            threading.Thread(target=self.snapshot_service, daemon=True).start()
    
    def stop_services(self):
        """Stop all HolyOS services"""
        self.log("Stopping HolyOS services...")
        # Services are daemon threads, they'll exit when main thread exits
    
    def log_service(self):
        """Background logging service"""
        while self.is_running():
            # Monitor system logs
            time.sleep(60)
    
    def network_service(self):
        """Background network service"""
        while self.is_running():
            # Monitor network connectivity
            time.sleep(30)
    
    def snapshot_service(self):
        """Automatic snapshot service"""
        last_snapshot = None
        
        while self.is_running():
            now = datetime.now()
            
            # Create daily snapshot at 3 AM
            if last_snapshot is None or (now - last_snapshot).days >= 1:
                if now.hour >= 3:  # After 3 AM
                    self.log("Creating automatic daily snapshot...")
                    self.create_snapshot(f"auto_{now.strftime('%Y%m%d')}", "daily")
                    last_snapshot = now
            
            time.sleep(3600)  # Check hourly
    
    # ==================== IMAGE MANAGEMENT ====================
    
    def create_image(self, name: str, template: str = "base") -> bool:
        """Create new HolyOS image"""
        try:
            self.log(f"Creating new image: {name} from template: {template}")
            
            image_path = HOLYOS_IMAGES / name
            if image_path.exists():
                self.log(f"Image {name} already exists!", "ERROR")
                return False
            
            # Create directory structure
            dirs = [
                "bin", "boot", "dev", "etc", "home", "lib", "lib64",
                "media", "mnt", "opt", "proc", "root", "run", "sbin",
                "srv", "sys", "tmp", "usr", "var"
            ]
            
            for d in dirs:
                (image_path / d).mkdir(parents=True, exist_ok=True)
            
            # Create minimal system files
            self.create_minimal_system(image_path)
            
            # Install selected template packages
            self.install_packages_to_image(image_path, template)
            
            # Create user accounts
            self.create_users(image_path)
            
            # Configure network
            self.configure_network(image_path)
            
            self.log(f"Image {name} created successfully")
            return True
            
        except Exception as e:
            self.log(f"Error creating image: {e}", "ERROR")
            return False
    
    def create_minimal_system(self, image_path: Path):
        """Create minimal Linux system structure"""
        self.log("Creating minimal system...")
        
        # Create essential directories
        etc_path = image_path / "etc"
        
        # Create passwd file
        passwd_content = """root:x:0:0:root:/root:/bin/bash
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin
"""
        (etc_path / "passwd").write_text(passwd_content)
        
        # Create group file
        group_content = """root:x:0:
nogroup:x:65534:
"""
        (etc_path / "group").write_text(group_content)
        
        # Create hosts file
        hosts_content = """127.0.0.1	localhost
::1		localhost ip6-localhost ip6-loopback
"""
        (etc_path / "hosts").write_text(hosts_content)
        
        # Create hostname
        (etc_path / "hostname").write_text("holyos\n")
        
        # Create fstab
        fstab_content = """proc	/proc	proc	defaults	0	0
sysfs	/sys	sysfs	defaults	0	0
tmpfs	/tmp	tmpfs	defaults	0	0
"""
        (etc_path / "fstab").write_text(fstab_content)
        
        # Create resolv.conf
        resolv_content = """nameserver 8.8.8.8
nameserver 1.1.1.1
"""
        (etc_path / "resolv.conf").write_text(resolv_content)
        
        # Create motd
        motd_content = """
=========================================
    Welcome to HolyOS Micro Distro!
    Version: 1.0.0
    Running in HolyCMD
=========================================
"""
        (etc_path / "motd").write_text(motd_content)
        
        # Create basic profile
        profile_content = """export PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin
export PS1='\\[\\033[01;32m\\]\\u@holyos\\[\\033[00m\\]:\\[\\033[01;34m\\]\\w\\[\\033[00m\\]\\$ '
export LANG=en_US.UTF-8
export TERM=xterm-256color

alias ls='ls --color=auto'
alias ll='ls -la'
alias la='ls -A'
"""
        (etc_path / "profile").write_text(profile_content)
        
        # Create root home
        root_home = image_path / "root"
        root_home.mkdir(exist_ok=True)
        (root_home / ".bashrc").write_text("source /etc/profile\n")
    
    def install_packages_to_image(self, image_path: Path, package_set: str):
        """Install packages to image"""
        self.log(f"Installing {package_set} packages...")
        
        packages = self.config["packages"].get(package_set, [])
        
        if not packages:
            self.log(f"No packages defined for {package_set}", "WARN")
            return
        
        # Download and install packages
        package_dir = HOLYOS_PACKAGES / package_set
        
        for pkg in packages:
            pkg_file = package_dir / f"{pkg}.pkg"
            
            if pkg_file.exists():
                self.install_package(image_path, pkg_file)
            else:
                self.log(f"Package {pkg} not found, downloading...", "WARN")
                if self.download_package(pkg, package_set):
                    self.install_package(image_path, pkg_file)
    
    def install_package(self, image_path: Path, pkg_file: Path):
        """Install single package to image"""
        try:
            # Extract package
            with tarfile.open(pkg_file, 'r:xz') as tar:
                tar.extractall(path=image_path)
            
            pkg_name = pkg_file.stem
            self.log(f"Package {pkg_name} installed")
            
        except Exception as e:
            self.log(f"Error installing package {pkg_file.name}: {e}", "ERROR")
    
    def download_package(self, pkg_name: str, repo: str) -> bool:
        """Download package from repository"""
        try:
            repo_url = self.config["repositories"]["main"]
            pkg_url = f"{repo_url}packages/{repo}/{pkg_name}.pkg.tar.xz"
            
            self.log(f"Downloading {pkg_name} from {repo_url}")
            
            response = requests.get(pkg_url, stream=True)
            if response.status_code == 200:
                pkg_file = HOLYOS_PACKAGES / repo / f"{pkg_name}.pkg"
                pkg_file.parent.mkdir(parents=True, exist_ok=True)
                
                with open(pkg_file, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                
                self.log(f"Package {pkg_name} downloaded")
                return True
            else:
                self.log(f"Failed to download {pkg_name}: HTTP {response.status_code}", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"Download error: {e}", "ERROR")
            return False
    
    def create_users(self, image_path: Path):
        """Create user accounts in image"""
        self.log("Creating user accounts...")
        
        etc_path = image_path / "etc"
        
        # Add holy user
        shadow_content = """root:*:19463:0:99999:7:::
holy:$6$rounds=656000$VqJjGkL3J7pC2D1A$WQe6f5M4p3L2k1J9H8G7F6E5D4C3B2A1Z0Y9X8W7V6U5T4S3R2Q1P0O9N8M7L6K5J4I3H2G1F0E9D8C7B6A5:19463:0:99999:7:::
"""
        (etc_path / "shadow").write_text(shadow_content)
        
        # Update passwd
        passwd_lines = (etc_path / "passwd").read_text().splitlines()
        passwd_lines.append("holy:x:1000:1000:Holy User:/home/holy:/bin/bash")
        (etc_path / "passwd").write_text("\n".join(passwd_lines))
        
        # Update group
        group_lines = (etc_path / "group").read_text().splitlines()
        group_lines.append("holy:x:1000:")
        (etc_path / "group").write_text("\n".join(group_lines))
        
        # Create home directory
        holy_home = image_path / "home" / "holy"
        holy_home.mkdir(parents=True, exist_ok=True)
        
        # Copy .bashrc
        shutil.copy(image_path / "root" / ".bashrc", holy_home / ".bashrc")
        
        # Set ownership (simulated)
        self.log("User 'holy' created with password 'holy'")
    
    def configure_network(self, image_path: Path):
        """Configure network settings"""
        etc_path = image_path / "etc"
        
        # Create network interfaces
        interfaces_content = """auto lo
iface lo inet loopback

auto eth0
iface eth0 inet dhcp
"""
        (etc_path / "network" / "interfaces").parent.mkdir(exist_ok=True)
        (etc_path / "network" / "interfaces").write_text(interfaces_content)
    
    def list_images(self) -> List[Dict]:
        """List all HolyOS images"""
        images = []
        
        for img_dir in HOLYOS_IMAGES.iterdir():
            if img_dir.is_dir():
                size = sum(f.stat().st_size for f in img_dir.rglob('*') if f.is_file())
                created = datetime.fromtimestamp(img_dir.stat().st_ctime)
                
                images.append({
                    "name": img_dir.name,
                    "size": self.human_size(size),
                    "created": created.strftime("%Y-%m-%d %H:%M"),
                    "path": str(img_dir)
                })
        
        return sorted(images, key=lambda x: x["name"])
    
    def delete_image(self, name: str, force: bool = False) -> bool:
        """Delete HolyOS image"""
        try:
            image_path = HOLYOS_IMAGES / name
            
            if not image_path.exists():
                self.log(f"Image {name} not found", "ERROR")
                return False
            
            if self.is_running() and self.current_image == name:
                self.log(f"Cannot delete running image {name}", "ERROR")
                return False
            
            if not force:
                # Check if image has snapshots
                snapshots = self.list_snapshots_for_image(name)
                if snapshots:
                    self.log(f"Image {name} has {len(snapshots)} snapshots. Use --force to delete.", "WARN")
                    return False
            
            # Delete image
            shutil.rmtree(image_path)
            self.log(f"Image {name} deleted")
            return True
            
        except Exception as e:
            self.log(f"Error deleting image: {e}", "ERROR")
            return False
    
    def clone_image(self, source: str, dest: str) -> bool:
        """Clone an image"""
        try:
            source_path = HOLYOS_IMAGES / source
            dest_path = HOLYOS_IMAGES / dest
            
            if not source_path.exists():
                self.log(f"Source image {source} not found", "ERROR")
                return False
            
            if dest_path.exists():
                self.log(f"Destination image {dest} already exists", "ERROR")
                return False
            
            # Copy image
            shutil.copytree(source_path, dest_path)
            self.log(f"Image {source} cloned to {dest}")
            return True
            
        except Exception as e:
            self.log(f"Error cloning image: {e}", "ERROR")
            return False
    
    # ==================== PACKAGE MANAGEMENT ====================
    
    def install(self, packages: List[str], image_name: str = None) -> bool:
        """Install packages to HolyOS image"""
        try:
            image_name = image_name or self.current_image or self.config["system"]["default_image"]
            image_path = HOLYOS_IMAGES / image_name
            
            if not image_path.exists():
                self.log(f"Image {image_name} not found", "ERROR")
                return False
            
            self.log(f"Installing packages to {image_name}: {', '.join(packages)}")
            
            success_count = 0
            for pkg in packages:
                # Determine package set
                pkg_set = self.find_package_set(pkg)
                
                if pkg_set:
                    pkg_file = HOLYOS_PACKAGES / pkg_set / f"{pkg}.pkg"
                    
                    if pkg_file.exists():
                        self.install_package(image_path, pkg_file)
                        success_count += 1
                    else:
                        self.log(f"Package {pkg} not found locally, downloading...", "WARN")
                        if self.download_package(pkg, pkg_set):
                            self.install_package(image_path, pkg_file)
                            success_count += 1
                else:
                    self.log(f"Package {pkg} not in any repository", "ERROR")
            
            self.log(f"Installed {success_count}/{len(packages)} packages")
            return success_count > 0
            
        except Exception as e:
            self.log(f"Install error: {e}", "ERROR")
            return False
    
    def remove(self, packages: List[str], image_name: str = None) -> bool:
        """Remove packages from HolyOS image"""
        try:
            image_name = image_name or self.current_image or self.config["system"]["default_image"]
            image_path = HOLYOS_IMAGES / image_name
            
            if not image_path.exists():
                self.log(f"Image {image_name} not found", "ERROR")
                return False
            
            self.log(f"Removing packages from {image_name}: {', '.join(packages)}")
            
            # Note: This is a simplified removal
            # In full implementation, you'd track installed files
            success_count = 0
            for pkg in packages:
                # Remove package tracking
                pkg_tracking_file = image_path / "var" / "lib" / "holyos" / "packages" / f"{pkg}.json"
                if pkg_tracking_file.exists():
                    pkg_tracking_file.unlink()
                    success_count += 1
                    self.log(f"Package {pkg} removed")
                else:
                    self.log(f"Package {pkg} not found in image", "WARN")
            
            self.log(f"Removed {success_count}/{len(packages)} packages")
            return success_count > 0
            
        except Exception as e:
            self.log(f"Remove error: {e}", "ERROR")
            return False
    
    def find_package_set(self, package_name: str) -> Optional[str]:
        """Find which package set contains a package"""
        for pkg_set, packages in self.config["packages"].items():
            if package_name in packages:
                return pkg_set
        return None
    
    def search_packages(self, query: str) -> List[Dict]:
        """Search for packages in repositories"""
        results = []
        
        for pkg_set, packages in self.config["packages"].items():
            for pkg in packages:
                if query.lower() in pkg.lower():
                    # Check if package is available
                    pkg_file = HOLYOS_PACKAGES / pkg_set / f"{pkg}.pkg"
                    installed = pkg_file.exists()
                    
                    results.append({
                        "name": pkg,
                        "set": pkg_set,
                        "installed": installed,
                        "description": f"Package from {pkg_set} set"
                    })
        
        return sorted(results, key=lambda x: x["name"])
    
    def update_packages(self, image_name: str = None) -> bool:
        """Update all packages in image"""
        try:
            image_name = image_name or self.current_image or self.config["system"]["default_image"]
            self.log(f"Updating packages for {image_name}...")
            
            # Get list of installed packages
            installed_packages = []
            
            # This would read from package tracking
            tracking_dir = HOLYOS_IMAGES / image_name / "var" / "lib" / "holyos" / "packages"
            if tracking_dir.exists():
                for pkg_file in tracking_dir.glob("*.json"):
                    installed_packages.append(pkg_file.stem)
            
            # Reinstall all packages
            if installed_packages:
                return self.install(installed_packages, image_name)
            else:
                self.log("No packages found to update", "WARN")
                return False
                
        except Exception as e:
            self.log(f"Update error: {e}", "ERROR")
            return False
    
    # ==================== SNAPSHOT MANAGEMENT ====================
    
    def create_snapshot(self, name: str, snapshot_type: str = "manual") -> bool:
        """Create snapshot of current image"""
        try:
            if not self.current_image:
                self.log("No image is currently booted", "ERROR")
                return False
            
            source_path = HOLYOS_IMAGES / self.current_image
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            snapshot_name = f"{name}_{timestamp}" if name != "auto" else f"auto_{timestamp}"
            
            snapshot_dir = HOLYOS_SNAPSHOTS / snapshot_type / snapshot_name
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            
            # Create snapshot manifest
            manifest = {
                "name": snapshot_name,
                "type": snapshot_type,
                "image": self.current_image,
                "created": datetime.now().isoformat(),
                "size": 0,
                "files": []
            }
            
            # Copy image with hardlinks to save space
            self.log(f"Creating snapshot {snapshot_name}...")
            
            # Use rsync if available for efficient copying
            rsync_cmd = [
                "rsync", "-a", "--link-dest=" + str(source_path),
                str(source_path) + "/",
                str(snapshot_dir) + "/"
            ]
            
            result = subprocess.run(rsync_cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                # Fallback to simple copy
                self.log("Rsync failed, using simple copy", "WARN")
                shutil.copytree(source_path, snapshot_dir, dirs_exist_ok=True)
            
            # Calculate size
            size = sum(f.stat().st_size for f in snapshot_dir.rglob('*') if f.is_file())
            manifest["size"] = size
            
            # Save manifest
            manifest_file = snapshot_dir / "snapshot.json"
            with open(manifest_file, 'w', encoding='utf-8') as f:
                json.dump(manifest, f, indent=2)
            
            # Compress if enabled
            if self.config["storage"]["snapshot_compression"]:
                self.compress_snapshot(snapshot_dir)
            
            self.log(f"Snapshot created: {snapshot_name} ({self.human_size(size)})")
            return True
            
        except Exception as e:
            self.log(f"Snapshot error: {e}", "ERROR")
            return False
    
    def compress_snapshot(self, snapshot_dir: Path):
        """Compress snapshot to save space"""
        try:
            snapshot_name = snapshot_dir.name
            parent_dir = snapshot_dir.parent
            
            # Create tar archive
            tar_path = parent_dir / f"{snapshot_name}.tar.xz"
            
            with tarfile.open(tar_path, 'w:xz') as tar:
                tar.add(snapshot_dir, arcname=snapshot_name)
            
            # Delete uncompressed directory
            shutil.rmtree(snapshot_dir)
            
            self.log(f"Snapshot compressed: {tar_path.name}")
            
        except Exception as e:
            self.log(f"Compression error: {e}", "WARN")
    
    def list_snapshots(self, snapshot_type: str = None) -> List[Dict]:
        """List all snapshots"""
        snapshots = []
        
        snapshot_types = [snapshot_type] if snapshot_type else ["daily", "manual"]
        
        for stype in snapshot_types:
            type_dir = HOLYOS_SNAPSHOTS / stype
            
            if type_dir.exists():
                for item in type_dir.iterdir():
                    if item.is_dir() or item.suffix in ['.tar', '.tar.gz', '.tar.xz']:
                        # Try to read manifest
                        manifest_file = item.with_suffix('.json') if item.is_file() else item / "snapshot.json"
                        
                        if manifest_file.exists():
                            try:
                                with open(manifest_file, 'r', encoding='utf-8') as f:
                                    manifest = json.load(f)
                                snapshots.append(manifest)
                            except:
                                # Create basic info
                                snapshots.append({
                                    "name": item.name,
                                    "type": stype,
                                    "created": datetime.fromtimestamp(item.stat().st_ctime).isoformat(),
                                    "size": item.stat().st_size if item.is_file() else 0,
                                    "compressed": item.is_file()
                                })
        
        return sorted(snapshots, key=lambda x: x["created"], reverse=True)
    
    def list_snapshots_for_image(self, image_name: str) -> List[Dict]:
        """List snapshots for specific image"""
        all_snapshots = self.list_snapshots()
        return [s for s in all_snapshots if s.get("image") == image_name]
    
    def restore_snapshot(self, snapshot_name: str, target_image: str = None) -> bool:
        """Restore image from snapshot"""
        try:
            # Find snapshot
            snapshot_path = None
            for stype in ["daily", "manual"]:
                type_dir = HOLYOS_SNAPSHOTS / stype
                for item in type_dir.iterdir():
                    if item.stem == snapshot_name or item.name == snapshot_name:
                        snapshot_path = item
                        break
                if snapshot_path:
                    break
            
            if not snapshot_path:
                self.log(f"Snapshot {snapshot_name} not found", "ERROR")
                return False
            
            target_image = target_image or self.current_image or f"restored_{snapshot_name}"
            target_path = HOLYOS_IMAGES / target_image
            
            if target_path.exists():
                self.log(f"Target image {target_image} already exists", "ERROR")
                return False
            
            self.log(f"Restoring {snapshot_name} to {target_image}...")
            
            if snapshot_path.is_file() and snapshot_path.suffix in ['.tar', '.tar.gz', '.tar.xz']:
                # Extract compressed snapshot
                with tarfile.open(snapshot_path, 'r:*') as tar:
                    tar.extractall(path=target_path.parent)
                
                # Rename if needed
                extracted_dir = target_path.parent / snapshot_path.stem
                if extracted_dir.exists() and extracted_dir != target_path:
                    extracted_dir.rename(target_path)
            else:
                # Copy directory
                shutil.copytree(snapshot_path, target_path)
            
            self.log(f"Snapshot {snapshot_name} restored to {target_image}")
            return True
            
        except Exception as e:
            self.log(f"Restore error: {e}", "ERROR")
            return False
    
    def delete_snapshot(self, snapshot_name: str) -> bool:
        """Delete snapshot"""
        try:
            # Find and delete snapshot
            for stype in ["daily", "manual"]:
                type_dir = HOLYOS_SNAPSHOTS / stype
                for item in type_dir.iterdir():
                    if item.stem == snapshot_name or item.name == snapshot_name:
                        if item.is_file():
                            item.unlink()
                        else:
                            shutil.rmtree(item)
                        
                        self.log(f"Snapshot {snapshot_name} deleted")
                        return True
            
            self.log(f"Snapshot {snapshot_name} not found", "ERROR")
            return False
            
        except Exception as e:
            self.log(f"Delete snapshot error: {e}", "ERROR")
            return False
    
    def cleanup_snapshots(self, days_old: int = None) -> int:
        """Cleanup old snapshots"""
        try:
            days = days_old or self.config["system"]["snapshot_retention"]
            cutoff = datetime.now().timestamp() - (days * 86400)
            
            deleted_count = 0
            
            for stype in ["daily", "manual"]:
                type_dir = HOLYOS_SNAPSHOTS / stype
                
                if type_dir.exists():
                    for item in type_dir.iterdir():
                        if item.stat().st_ctime < cutoff:
                            if item.is_file():
                                item.unlink()
                            else:
                                shutil.rmtree(item)
                            deleted_count += 1
            
            self.log(f"Cleaned up {deleted_count} old snapshots")
            return deleted_count
            
        except Exception as e:
            self.log(f"Cleanup error: {e}", "ERROR")
            return 0
    
    # ==================== SYSTEM INFO ====================
    
    def status(self) -> Dict:
        """Get HolyOS status"""
        status = {
            "running": self.is_running(),
            "current_image": self.current_image,
            "boot_pid": self.boot_pid,
            "config": {
                "name": self.config["system"]["name"],
                "version": self.config["system"]["version"],
                "arch": self.config["system"]["arch"]
            },
            "images": len(self.list_images()),
            "snapshots": len(self.list_snapshots()),
            "storage": {
                "total": self.get_storage_usage(),
                "images": self.get_directory_size(HOLYOS_IMAGES),
                "snapshots": self.get_directory_size(HOLYOS_SNAPSHOTS),
                "packages": self.get_directory_size(HOLYOS_PACKAGES)
            }
        }
        
        return status
    
    def get_storage_usage(self) -> str:
        """Get total storage usage"""
        total = 0
        for root_dir in [HOLYOS_IMAGES, HOLYOS_SNAPSHOTS, HOLYOS_PACKAGES]:
            total += self.get_directory_size(root_dir)
        
        return self.human_size(total)
    
    def get_directory_size(self, directory: Path) -> int:
        """Calculate directory size in bytes"""
        if not directory.exists():
            return 0
        
        total = 0
        for file in directory.rglob('*'):
            if file.is_file():
                total += file.stat().st_size
        
        return total
    
    def human_size(self, bytes: int) -> str:
        """Convert bytes to human readable size"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes < 1024.0:
                return f"{bytes:.2f} {unit}"
            bytes /= 1024.0
        return f"{bytes:.2f} PB"
    
    # ==================== EXPORT/IMPORT ====================
    
    def export_image(self, image_name: str, output_path: str) -> bool:
        """Export image to archive"""
        try:
            image_path = HOLYOS_IMAGES / image_name
            
            if not image_path.exists():
                self.log(f"Image {image_name} not found", "ERROR")
                return False
            
            output = Path(output_path)
            if output.suffix not in ['.tar', '.tar.gz', '.tar.xz', '.zip']:
                output = output.with_suffix('.tar.xz')
            
            self.log(f"Exporting {image_name} to {output}...")
            
            if output.suffix == '.zip':
                with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for file in image_path.rglob('*'):
                        if file.is_file():
                            arcname = file.relative_to(image_path)
                            zipf.write(file, arcname)
            else:
                # Tar archive
                mode = {
                    '.tar': 'w',
                    '.tar.gz': 'w:gz',
                    '.tar.xz': 'w:xz'
                }.get(output.suffix, 'w:xz')
                
                with tarfile.open(output, mode) as tar:
                    tar.add(image_path, arcname=image_name)
            
            self.log(f"Image exported: {output}")
            return True
            
        except Exception as e:
            self.log(f"Export error: {e}", "ERROR")
            return False
    
    def import_image(self, archive_path: str, image_name: str = None) -> bool:
        """Import image from archive"""
        try:
            archive = Path(archive_path)
            
            if not archive.exists():
                self.log(f"Archive {archive_path} not found", "ERROR")
                return False
            
            if image_name is None:
                image_name = archive.stem
            
            image_path = HOLYOS_IMAGES / image_name
            
            if image_path.exists():
                self.log(f"Image {image_name} already exists", "ERROR")
                return False
            
            self.log(f"Importing image {image_name} from {archive}...")
            
            if archive.suffix == '.zip':
                with zipfile.ZipFile(archive, 'r') as zipf:
                    zipf.extractall(image_path)
            else:
                # Tar archive
                with tarfile.open(archive, 'r:*') as tar:
                    tar.extractall(path=image_path.parent)
            
            # If extracted to different directory, rename
            extracted_dir = image_path.parent / archive.stem
            if extracted_dir.exists() and extracted_dir != image_path:
                extracted_dir.rename(image_path)
            
            self.log(f"Image imported: {image_name}")
            return True
            
        except Exception as e:
            self.log(f"Import error: {e}", "ERROR")
            return False
    
    
    # ==================== UTILITIES ====================
    
    def run_command(self, command: str, image_name: str = None) -> Tuple[bool, str]:
        """Run command in HolyOS image"""
        try:
            image_name = image_name or self.current_image
            if not image_name:
                self.log("No image specified or running", "ERROR")
                return False, "No image"
            
            image_path = HOLYOS_IMAGES / image_name
            
            if not image_path.exists():
                return False, f"Image {image_name} not found"
            
            # Use chroot to run command
            cmd = ["chroot", str(image_path), "sh", "-c", command]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            output = result.stdout
            if result.stderr:
                output += "\n" + result.stderr
            
            return result.returncode == 0, output
            
        except subprocess.TimeoutExpired:
            return False, "Command timeout"
        except Exception as e:
            return False, str(e)
    
    def repair_image(self, image_name: str) -> bool:
        """Repair corrupted image"""
        try:
            self.log(f"Repairing image {image_name}...")
            image_path = HOLYOS_IMAGES / image_name
            
            if not image_path.exists():
                self.log(f"Image {image_name} not found", "ERROR")
                return False
            
            # Recreate essential directories
            essential_dirs = ["bin", "etc", "lib", "usr", "var", "proc", "sys", "dev"]
            for d in essential_dirs:
                (image_path / d).mkdir(exist_ok=True)
            
            # Recreate essential files
            self.create_minimal_system(image_path)
            
            self.log(f"Image {image_name} repaired")
            return True
            
        except Exception as e:
            self.log(f"Repair error: {e}", "ERROR")
            return False

# ==================== HOLYOS COMMANDS ====================

def holyos_boot(args):
    """Boot HolyOS"""
    holyos = HolyOS()
    
    image = args[0] if args else None
    method = args[1] if len(args) > 1 else None
    
    if holyos.boot(image, method):
        print("✅ HolyOS booted successfully!")
        print("Type 'holyos shell' to enter the OS")
    else:
        print("❌ Failed to boot HolyOS")

def holyos_shutdown(args):
    """Shutdown HolyOS"""
    holyos = HolyOS()
    force = "--force" in args
    
    if holyos.shutdown(force):
        print("✅ HolyOS shutdown complete")
    else:
        print("❌ Failed to shutdown HolyOS")

def holyos_status(args):
    """Show HolyOS status"""
    holyos = HolyOS()
    status = holyos.status()
    
    print("=" * 50)
    print("🧿 HolyOS Status")
    print("=" * 50)
    
    print(f"Status: {'🟢 RUNNING' if status['running'] else '🔴 STOPPED'}")
    print(f"Current Image: {status['current_image'] or 'None'}")
    print(f"Version: {status['config']['version']}")
    print(f"Architecture: {status['config']['arch']}")
    print()
    print(f"Images: {status['images']}")
    print(f"Snapshots: {status['snapshots']}")
    print()
    print("Storage Usage:")
    print(f"  Total: {status['storage']['total']}")
    print(f"  Images: {status['storage']['images']}")
    print(f"  Snapshots: {status['storage']['snapshots']}")
    print(f"  Packages: {status['storage']['packages']}")
    print("=" * 50)

def holyos_images(args):
    """List HolyOS images"""
    holyos = HolyOS()
    images = holyos.list_images()
    
    if not images:
        print("No HolyOS images found")
        return
    
    print(f"{'Name':<20} {'Size':<12} {'Created':<20} {'Path'}")
    print("-" * 80)
    
    for img in images:
        current = " *" if holyos.current_image == img["name"] else ""
        print(f"{img['name']:<20}{current:<2} {img['size']:<12} {img['created']:<20} {img['path'][:30]}...")

def holyos_create(args):
    """Create new HolyOS image"""
    if not args:
        print("Usage: holyos create <name> [template]")
        print("Templates: base, core, net, dev, gui, games")
        return
    
    name = args[0]
    template = args[1] if len(args) > 1 else "base"
    
    holyos = HolyOS()
    
    if holyos.create_image(name, template):
        print(f"✅ Image '{name}' created from template '{template}'")
    else:
        print(f"❌ Failed to create image '{name}'")

def holyos_install(args):
    """Install packages to HolyOS"""
    if not args:
        print("Usage: holyos install <package1> [package2 ...]")
        print("Example: holyos install python3 git vim")
        return
    
    holyos = HolyOS()
    
    if holyos.install(args):
        print("✅ Packages installed successfully")
    else:
        print("❌ Failed to install packages")

def holyos_snapshot(args):
    """Create snapshot"""
    if not args:
        print("Usage: holyos snapshot <name> [type]")
        print("Types: manual (default), daily")
        return
    
    name = args[0]
    snapshot_type = args[1] if len(args) > 1 else "manual"
    
    holyos = HolyOS()
    
    if holyos.create_snapshot(name, snapshot_type):
        print(f"✅ Snapshot '{name}' created")
    else:
        print(f"❌ Failed to create snapshot")

def holyos_snapshots(args):
    """List snapshots"""
    holyos = HolyOS()
    snapshots = holyos.list_snapshots()
    
    if not snapshots:
        print("No snapshots found")
        return
    
    print(f"{'Name':<25} {'Type':<10} {'Size':<12} {'Created':<20}")
    print("-" * 70)
    
    for snap in snapshots:
        compressed = "📦" if snap.get("compressed") else "📁"
        print(f"{snap['name']:<25} {snap['type']:<10} {snap.get('size', 'N/A'):<12} {snap['created'][:19]:<20} {compressed}")

def holyos_restore(args):
    """Restore snapshot"""
    if not args:
        print("Usage: holyos restore <snapshot> [target_image]")
        return
    
    snapshot = args[0]
    target = args[1] if len(args) > 1 else None
    
    holyos = HolyOS()
    
    if holyos.restore_snapshot(snapshot, target):
        print(f"✅ Snapshot '{snapshot}' restored")
    else:
        print(f"❌ Failed to restore snapshot")

def holyos_shell(args):
    """Enter HolyOS shell"""
    holyos = HolyOS()
    
    if not holyos.is_running():
        print("HolyOS is not running. Use 'holyos boot' first.")
        return
    
    image_name = holyos.current_image or holyos.config["system"]["default_image"]
    image_path = HOLYOS_IMAGES / image_name
    
    print(f"Entering HolyOS shell (image: {image_name})")
    print("Type 'exit' to return to HolyCMD")
    print("-" * 50)
    
    # Simple shell simulation
    while True:
        try:
            cmd = input(f"holyos:{image_name}$ ")
            
            if cmd.lower() in ['exit', 'quit']:
                break
            
            success, output = holyos.run_command(cmd, image_name)
            
            if output:
                print(output)
            
            if not success:
                print(f"Command failed")
                
        except KeyboardInterrupt:
            print("\nExiting HolyOS shell")
            break
        except EOFError:
            break

def holyos_help(args):
    """Show HolyOS help"""
    help_text = """
🧿 HolyOS - Micro Linux Distribution for HolyCMD

COMMANDS:
  holyos boot [image] [method]    - Boot HolyOS (chroot/proot/container)
  holyos shutdown [--force]       - Shutdown HolyOS
  holyos status                   - Show HolyOS status
  holyos shell                    - Enter HolyOS interactive shell
  
  holyos images                   - List all images
  holyos create <name> [template] - Create new image
  holyos delete <name> [--force]  - Delete image
  holyos clone <src> <dest>       - Clone image
  holyos repair <name>            - Repair corrupted image
  
  holyos install <pkg1> [pkg2]    - Install packages
  holyos remove <pkg1> [pkg2]     - Remove packages
  holyos search <query>           - Search packages
  holyos update [image]           - Update all packages
  
  holyos snapshot <name> [type]   - Create snapshot
  holyos snapshots                - List snapshots
  holyos restore <snap> [target]  - Restore snapshot
  holyos cleanup [days]           - Cleanup old snapshots
  
  holyos export <img> <file>      - Export image to archive
  holyos import <file> [name]     - Import image from archive
  
  holyos network                  - Show network info
  holyos config                   - Show configuration
  holyos config set <key> <value> - Set configuration
  
  holyos help                     - Show this help

TEMPLATES:
  base  - Minimal system
  core  - Base + core utilities
  net   - Core + networking
  dev   - Net + development tools
  gui   - Dev + graphical apps
  games - Gui + games

EXAMPLES:
  holyos create myos dev
  holyos boot myos
  holyos install python3 git vim
  holyos snapshot before-update
  holyos shell
"""
    print(help_text)

# ==================== MAIN COMMAND HANDLER ====================

def holyos_main(args):
    """Main HolyOS command handler"""
    if not args:
        holyos_help([])
        return
    
    command = args[0].lower()
    
    commands = {
        "boot": holyos_boot,
        "shutdown": holyos_shutdown,
        "status": holyos_status,
        "shell": holyos_shell,
        "images": holyos_images,
        "create": holyos_create,
        "delete": lambda a: print("TODO: Implement delete"),
        "clone": lambda a: print("TODO: Implement clone"),
        "repair": lambda a: print("TODO: Implement repair"),
        "install": holyos_install,
        "remove": lambda a: print("TODO: Implement remove"),
        "search": lambda a: print("TODO: Implement search"),
        "update": lambda a: print("TODO: Implement update"),
        "snapshot": holyos_snapshot,
        "snapshots": holyos_snapshots,
        "restore": holyos_restore,
        "cleanup": lambda a: print("TODO: Implement cleanup"),
        "export": lambda a: print("TODO: Implement export"),
        "import": lambda a: print("TODO: Implement import"),
        "network": lambda a: print("TODO: Implement network"),
        "config": lambda a: print("TODO: Implement config"),
        "help": holyos_help,
    }
    
    if command in commands:
        commands[command](args[1:])
    else:
        print(f"Unknown command: {command}")
        print("Use 'holyos help' for available commands")

# ==================== REGISTRATION FOR HOLYCMD ====================

def register():
    """Register HolyOS commands with HolyCMD"""
    return {
        "holyos": holyos_main,
        "holyos-boot": lambda a: holyos_boot([]),  # Shortcut
        "holyos-shell": lambda a: holyos_shell([]),  # Shortcut
        "holyos-status": lambda a: holyos_status([]),  # Shortcut
    }

if __name__ == "__main__":
    # Test if run directly
    print("🧿 HolyOS v1.0 - Testing mode")
    holyos_main(sys.argv[1:])