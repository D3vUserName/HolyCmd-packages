import socket
import requests
import json
import ipaddress
import yaml
from pathlib import Path
from typing import Dict, Optional

# ============================================
# SYSTEM TŁUMACZEŃ (INTEGRACJA Z LOCALES.YML)
# ============================================

# Fallback tylko dla absolutnie krytycznych tekstów
CRITICAL_FALLBACK = {
    "en": {
        "error": "❌ Error",
        "usage": "Usage:",
        "example": "Example:"
    },
    "pl": {
        "error": "❌ Błąd",
        "usage": "Użycie:",
        "example": "Przykład:"
    },
    "fr": {
        "error": "❌ Erreur",
        "usage": "Utilisation:",
        "example": "Exemple:"
    },
    "de": {
        "error": "❌ Fehler",
        "usage": "Verwendung:",
        "example": "Beispiel:"
    }
}

# Globalne zmienne tłumaczeń
_TRANSLATIONS = {}
_CURRENT_LANG = "en"
_PACKAGE_NAME = "iplookup"

def _load_translations():
    """Ładuje tłumaczenia z głównego pliku locales.yml HolyCMD"""
    global _TRANSLATIONS, _CURRENT_LANG
    
    try:
        # 1. Znajdź folder konfiguracyjny HolyCMD
        config_dir = Path.home() / ".holycmd"
        
        # 2. Załaduj aktualny język z konfiguracji HolyCMD
        lang_file = config_dir / "language.json"
        if lang_file.exists():
            try:
                with open(lang_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    _CURRENT_LANG = data.get("language", "en")
            except:
                _CURRENT_LANG = "en"
        else:
            _CURRENT_LANG = "en"
        
        # 3. Załaduj plik locales.yml
        locales_file = config_dir / "locales.yml"
        if not locales_file.exists():
            # Brak pliku tłumaczeń
            _TRANSLATIONS = {}
            return False
        
        # 4. Wczytaj YAML
        with open(locales_file, 'r', encoding='utf-8') as f:
            locales_data = yaml.safe_load(f)
        
        if not locales_data or 'languages' not in locales_data:
            # Uszkodzony plik
            _TRANSLATIONS = {}
            return False
        
        # 5. Sprawdź czy mamy tłumaczenia dla aktualnego języka
        if _CURRENT_LANG not in locales_data['languages']:
            # Język nie istnieje, spróbuj angielski
            if 'en' in locales_data['languages']:
                _CURRENT_LANG = 'en'
                lang_data = locales_data['languages']['en']
            else:
                # Brak jakichkolwiek tłumaczeń
                _TRANSLATIONS = {}
                return False
        else:
            lang_data = locales_data['languages'][_CURRENT_LANG]
        
        # 6. Pobierz tłumaczenia dla pakietu iplookup
        if ('packages' in lang_data and 
            _PACKAGE_NAME in lang_data['packages']):
            _TRANSLATIONS = lang_data['packages'][_PACKAGE_NAME]
            return True
        else:
            # Brak tłumaczeń dla tego pakietu
            _TRANSLATIONS = {}
            return False
            
    except Exception as e:
        # W przypadku błędu, użyj pustych tłumaczeń
        _TRANSLATIONS = {}
        return False

def t(key: str, category: str = "ui", default: str = None) -> str:
    """Pobiera przetłumaczony tekst z locales.yml"""
    # Jeśli nie mamy załadowanych tłumaczeń, spróbuj załadować
    if not _TRANSLATIONS:
        _load_translations()
    
    # Spróbuj pobrać tłumaczenie
    if (category in _TRANSLATIONS and 
        key in _TRANSLATIONS[category]):
        return _TRANSLATIONS[category][key]
    
    # Jeśli nie ma tłumaczenia, użyj domyślnego
    if default:
        return default
    
    # Ostateczny fallback dla krytycznych tekstów
    if key in ["error", "usage", "example"]:
        if _CURRENT_LANG in CRITICAL_FALLBACK and key in CRITICAL_FALLBACK[_CURRENT_LANG]:
            return CRITICAL_FALLBACK[_CURRENT_LANG][key]
        elif "en" in CRITICAL_FALLBACK and key in CRITICAL_FALLBACK["en"]:
            return CRITICAL_FALLBACK["en"][key]
    
    # Jeśli nic nie znaleziono, zwróć klucz
    return key

def ct(key: str) -> str:
    """Pobiera przetłumaczoną nazwę komendy"""
    return t(key, "commands", key)

def dt(key: str) -> str:
    """Pobiera przetłumaczony opis komendy"""
    return t(key, "descriptions", "")

def ut(key: str) -> str:
    """Pobiera przetłumaczoną składnię użycia"""
    return t(key, "usage", key)

def et(key: str) -> str:
    """Pobiera przetłumaczony przykład"""
    return t(key, "examples", key)

# ============================================
# GŁÓWNE FUNKCJE PAKIETU
# ============================================

def register():
    """Rejestracja komend pakietu"""
    # Załaduj tłumaczenia przy starcie
    _load_translations()
    
    return {
        "iplookup": ip_lookup,
        "ipinfo": ip_info,
        "ipgeo": ip_geolocation,
        "ipscan": ip_scan,
        "dnsresolve": dns_resolve,
        "reverse_dns": reverse_dns_lookup,
        "myip": show_my_ip,
        "ipcalc": ip_calculator,
        "whois": whois_lookup,
        "subnet": subnet_info
    }

def ip_lookup(args):
    """
    Główna komenda IP Lookup - pokazuje wszystkie dostępne opcje
    """
    # Odśwież tłumaczenia
    _load_translations()
    
    print(f"\n{t('title', 'ui', '🌐 HolyCMD IP Lookup Toolkit')}\n")
    print(f"{t('available_commands', 'ui', 'Available commands:')}")
    print("=" * 50)
    
    commands = [
        "iplookup", "ipinfo", "ipgeo", "ipscan", "dnsresolve",
        "reverse_dns", "myip", "ipcalc", "whois", "subnet"
    ]
    
    for cmd in commands:
        cmd_name = ct(cmd)
        description = dt(cmd)
        if description:
            print(f"  {cmd:20} - {cmd_name}: {description}")
        else:
            print(f"  {cmd:20} - {cmd_name}")
    
    print(f"\n{t('examples', 'ui', 'Examples:')}")
    print("=" * 50)
    
    for cmd in commands:
        example = et(cmd)
        print(f"  {example}")

def ip_info(args):
    """
    Szczegółowe informacje o adresie IP lub hostname
    """
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('ipinfo')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('ipinfo')}")
        return
    
    target = args[0]
    
    print(f"{t('analyzing', 'ui', 'Analyzing:')} {target}")
    print("=" * 50)
    
    try:
        # Sprawdź czy to IP czy hostname
        try:
            # Jeśli to IP
            ip_obj = ipaddress.ip_address(target)
            ip = target
            hostname = None
        except ValueError:
            # Jeśli to hostname - rozwiąż DNS
            try:
                ip = socket.gethostbyname(target)
                ip_obj = ipaddress.ip_address(ip)
                hostname = target
            except socket.gaierror:
                print(f"{t('error')}: {t('cannot_resolve', 'ui', 'Cannot resolve hostname')}: {target}")
                return
        
        # Pobierz publiczne informacje o IP
        try:
            response = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
            if response.status_code == 200:
                data = response.json()
                
                print(f"{t('geolocation', 'ui', '📍 GEOLOCATION:')}")
                if data.get("status") == "success":
                    print(f"  {t('country', 'ui', 'Country')}: {data.get('country', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('region', 'ui', 'Region')}: {data.get('regionName', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('city', 'ui', 'City')}: {data.get('city', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('zip', 'ui', 'Zip')}: {data.get('zip', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('latitude', 'ui', 'Latitude')}: {data.get('lat', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('longitude', 'ui', 'Longitude')}: {data.get('lon', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('timezone', 'ui', 'Timezone')}: {data.get('timezone', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('isp', 'ui', 'ISP')}: {data.get('isp', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('organization', 'ui', 'Organization')}: {data.get('org', t('no_data', 'ui', 'N/A'))}")
                    print(f"  {t('as', 'ui', 'AS')}: {data.get('as', t('no_data', 'ui', 'N/A'))}")
                else:
                    print(f"  {t('service_error', 'ui', '(service error)')}")
            else:
                print(f"  {t('connection_error', 'ui', '(connection error)')}")
        except:
            print(f"  {t('service_error', 'ui', '(service error)')}")
        
        print(f"\n{t('technical_info', 'ui', '🔧 TECHNICAL INFORMATION:')}")
        print(f"  {t('ip_address', 'ui', 'IP address')}: {ip}")
        if hostname:
            print(f"  {t('hostname', 'ui', 'Hostname')}: {hostname}")
        
        # Reverse DNS
        try:
            rev_dns = socket.gethostbyaddr(ip)[0]
            print(f"  {t('reverse_dns', 'ui', 'Reverse DNS')}: {rev_dns}")
        except:
            print(f"  {t('reverse_dns', 'ui', 'Reverse DNS')}: {t('not_resolved', 'ui', '(none)')}")
        
        print(f"  {t('ip_type', 'ui', 'IP type')}: {'IPv4' if ip_obj.version == 4 else 'IPv6'}")
        
        # Sprawdź czy IP jest prywatne
        if ip_obj.is_private:
            print(f"  {t('range_type', 'ui', 'Range')}: {t('private_range', 'ui', 'PRIVATE')}")
            if ip_obj.is_loopback:
                print(f"  {t('loopback', 'ui', 'Loopback')}: YES")
            if ip_obj.is_link_local:
                print(f"  {t('link_local', 'ui', 'Link-local')}: YES")
            if ip_obj.is_multicast:
                print(f"  {t('multicast', 'ui', 'Multicast')}: YES")
        else:
            print(f"  {t('range_type', 'ui', 'Range')}: {t('public_range', 'ui', 'PUBLIC')}")
            if ip_obj.is_global:
                print(f"  {t('global', 'ui', 'Global')}: YES")
            if ip_obj.is_reserved:
                print(f"  {t('reserved', 'ui', 'Reserved')}: YES")
        
        # Sprawdź porty
        print(f"\n{t('port_check', 'ui', '🧪 PORT CHECK (basic):')}")
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 3389, 8080]
        
        if ip_obj.is_private:
            print(f"  {t('skip_scan', 'ui', '(Skip scanning for private IPs)')}")
        else:
            print(f"  {t('open_ports', 'ui', 'Open ports:')}")
            open_ports = []
            for port in common_ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    try:
                        service = socket.getservbyport(port)
                        open_ports.append((port, service))
                        print(f"    {port}/tcp - {service}")
                    except:
                        open_ports.append((port, "unknown"))
                        print(f"    {port}/tcp - unknown")
                sock.close()
            
            if not open_ports:
                print(f"    {t('no_open_ports', 'ui', '(no open ports)')}")
        
        # Blacklist check
        print(f"\n{t('blacklist_check', 'ui', '🌐 BLACKLIST CHECK (basic):')}")
        try:
            blacklists = ["zen.spamhaus.org", "bl.spamcop.net", "dnsbl.sorbs.net"]
            
            for bl in blacklists:
                try:
                    query = ".".join(reversed(str(ip).split("."))) + f".{bl}"
                    socket.gethostbyname(query)
                    print(f"  ❌ {t('found_on', 'ui', 'Found on')} {bl}")
                except:
                    print(f"  ✓ {t('not_found_on', 'ui', 'Not found on')} {bl}")
        except:
            print(f"  {t('service_error', 'ui', '(service error)')}")
        
    except Exception as e:
        print(f"{t('error')}: {e}")

def ip_geolocation(args):
    """
    Geolokalizacja adresu IP
    """
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('ipgeo')}")
        return
    
    target = args[0]
    
    print(f"📍 {ct('ipgeo')}: {target}")
    print("=" * 40)
    
    try:
        # Pobierz IP z hostname jeśli potrzeba
        try:
            ipaddress.ip_address(target)
            ip = target
        except ValueError:
            ip = socket.gethostbyname(target)
        
        response = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("status") == "success":
                print(f"🌍 {t('country', 'ui', 'Country')}: {data.get('country', 'N/A')} ({data.get('countryCode', '')})")
                print(f"🏙️ {t('region', 'ui', 'Region')}: {data.get('regionName', 'N/A')} ({data.get('region', '')})")
                print(f"🏠 {t('city', 'ui', 'City')}: {data.get('city', 'N/A')}")
                print(f"📮 {t('zip', 'ui', 'Zip')}: {data.get('zip', 'N/A')}")
                print(f"📡 {t('latitude', 'ui', 'Latitude')}/{t('longitude', 'ui', 'Longitude')}: {data.get('lat', 'N/A')}, {data.get('lon', 'N/A')}")
                print(f"⏰ {t('timezone', 'ui', 'Timezone')}: {data.get('timezone', 'N/A')}")
                print(f"📶 {t('isp', 'ui', 'ISP')}: {data.get('isp', 'N/A')}")
                print(f"🏢 {t('organization', 'ui', 'Organization')}: {data.get('org', 'N/A')}")
                print(f"🔗 {t('as', 'ui', 'AS')}: {data.get('as', 'N/A')}")
                
                # Map link
                lat = data.get('lat')
                lon = data.get('lon')
                if lat and lon:
                    print(f"\n{t('map', 'ui', '🗺️ Map:')}")
                    print(f"  https://www.google.com/maps?q={lat},{lon}")
                    print(f"  https://www.openstreetmap.org/?mlat={lat}&mlon={lon}")
            else:
                print(f"{t('error')}: {t('service_error', 'ui', 'Service error')}")
        else:
            print(f"{t('error')}: {t('connection_error', 'ui', 'Connection error')}")
            
    except Exception as e:
        print(f"{t('error')}: {e}")

def ip_scan(args):
    """Skanowanie podsieci"""
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('ipscan')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('ipscan')}")
        return
    
    network_str = args[0]
    
    try:
        if "/" in network_str:
            network = ipaddress.ip_network(network_str, strict=False)
        else:
            print(f"{t('error')}: {t('usage_error', 'ui', 'Usage error')}")
            return
        
        print(f"{t('network_scan', 'ui', '🔍 Network scanning:')} {network}")
        print(f"   {t('range', 'ui', 'Range')}: {network.network_address} - {network.broadcast_address}")
        print(f"   {t('hosts_count', 'ui', 'Number of hosts')}: {network.num_addresses - 2}")
        print("=" * 50)
        
        max_hosts = min(20, network.num_addresses)
        hosts_scanned = 0
        active_hosts = []
        
        for ip in network.hosts():
            if hosts_scanned >= max_hosts:
                print(f"\n{t('warning', 'ui', '⚠️ Warning')} {t('interrupted', 'ui', 'Interrupted after')} {max_hosts} {t('hosts_limit', 'ui', 'hosts (safety limit)')}")
                break
            
            hosts_scanned += 1
            ip_str = str(ip)
            
            print(f"  {ip_str}: ", end="", flush=True)
            
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.3)
                result = sock.connect_ex((ip_str, 80))
                
                if result == 0:
                    try:
                        hostname = socket.gethostbyaddr(ip_str)[0]
                        print(f"✓ {t('active', 'ui', 'ACTIVE')} ({hostname})")
                        active_hosts.append((ip_str, hostname))
                    except:
                        print(f"✓ {t('active', 'ui', 'ACTIVE')}")
                        active_hosts.append((ip_str, None))
                else:
                    print(f"✗ {t('not_found', 'ui', 'INACTIVE')}")
                
                sock.close()
                
            except:
                print(f"✗ {t('not_found', 'ui', 'INACTIVE')}")
        
        print(f"\n{t('summary', 'ui', '📊 SUMMARY:')}")
        print(f"   {t('scanned', 'ui', 'Scanned')}: {hosts_scanned} {t('hosts', 'ui', 'hosts')}")
        print(f"   {t('active', 'ui', 'Active')}: {len(active_hosts)} {t('hosts', 'ui', 'hosts')}")
        
        if active_hosts:
            print(f"\n{t('active_hosts', 'ui', '🎯 ACTIVE HOSTS:')}")
            for ip, hostname in active_hosts:
                if hostname:
                    print(f"   {ip} -> {hostname}")
                else:
                    print(f"   {ip}")
        
    except Exception as e:
        print(f"{t('error')}: {e}")

def dns_resolve(args):
    """Rozwiązywanie DNS"""
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('dnsresolve')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('dnsresolve')}")
        return
    
    hostname = args[0]
    
    print(f"{t('dns_resolution', 'ui', '🔍 DNS resolution for:')} {hostname}")
    print("=" * 50)
    
    try:
        print(f"{t('a_records', 'ui', '📡 A records (IPv4):')}")
        try:
            a_records = socket.gethostbyname_ex(hostname)[2]
            for ip in a_records:
                print(f"  {ip}")
        except:
            print(f"  {t('none', 'ui', '(none)')}")
        
        print(f"\n{t('aaaa_records', 'ui', '📡 AAAA records (IPv6):')}")
        try:
            aaaa_info = socket.getaddrinfo(hostname, None, socket.AF_INET6)
            ipv6_addrs = set()
            for info in aaaa_info:
                ipv6_addrs.add(info[4][0])
            
            for ip in ipv6_addrs:
                print(f"  {ip}")
        except:
            print(f"  {t('none', 'ui', '(none)')}")
        
        print(f"\n{t('mx_records', 'ui', '📨 MX records (Mail Exchange):')}")
        try:
            import dns.resolver
            mx_records = dns.resolver.resolve(hostname, 'MX')
            for mx in mx_records:
                print(f"  {mx.preference} {mx.exchange}")
        except:
            try:
                import subprocess
                result = subprocess.run(['nslookup', '-type=mx', hostname], 
                                      capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    if 'mail exchanger' in line:
                        print(f"  {line.strip()}")
            except:
                print(f"  {t('service_error', 'ui', '(service error)')}")
        
        print(f"\n{t('txt_records', 'ui', '📝 TXT records:')}")
        try:
            txt_records = dns.resolver.resolve(hostname, 'TXT')
            for txt in txt_records:
                print(f"  {txt}")
        except:
            print(f"  {t('none', 'ui', '(none)')}")
        
        print(f"\n{t('cname', 'ui', '🏷️ Canonical Name (CNAME):')}")
        try:
            cname = dns.resolver.resolve(hostname, 'CNAME')
            for c in cname:
                print(f"  {c.target}")
        except:
            print(f"  {t('none', 'ui', '(none)')}")
        
        print(f"\n{t('ns_records', 'ui', '🌐 Name Servers (NS):')}")
        try:
            ns_records = dns.resolver.resolve(hostname, 'NS')
            for ns in ns_records:
                print(f"  {ns.target}")
        except:
            print(f"  {t('none', 'ui', '(none)')}")
        
        print(f"\n{t('soa_record', 'ui', '⚙️ SOA Record:')}")
        try:
            soa = dns.resolver.resolve(hostname, 'SOA')
            for s in soa:
                print(f"  MNAME: {s.mname}")
                print(f"  RNAME: {s.rname}")
                print(f"  Serial: {s.serial}")
                print(f"  Refresh: {s.refresh}")
                print(f"  Retry: {s.retry}")
                print(f"  Expire: {s.expire}")
                print(f"  Minimum: {s.minimum}")
        except:
            print(f"  {t('none', 'ui', '(none)')}")
        
    except socket.gaierror:
        print(f"{t('error')}: {t('cannot_resolve', 'ui', 'Cannot resolve hostname')}")
    except Exception as e:
        print(f"{t('error')}: {e}")

def reverse_dns_lookup(args):
    """Reverse DNS lookup"""
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('reverse_dns')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('reverse_dns')}")
        return
    
    ip = args[0]
    
    print(f"{t('reverse_dns_for', 'ui', '🔄 Reverse DNS for:')} {ip}")
    print("=" * 40)
    
    try:
        ipaddress.ip_address(ip)
        
        hostname, aliases, ips = socket.gethostbyaddr(ip)
        
        print(f"🏷️ {t('hostname', 'ui', 'Hostname')}: {hostname}")
        
        if aliases:
            print(f"📛 Aliases: {', '.join(aliases)}")
        
        print(f"📡 IPs: {', '.join(ips)}")
        
        try:
            all_ips = socket.gethostbyname_ex(hostname)[2]
            if len(all_ips) > 1:
                print(f"\n🌐 All IPs for {hostname}:")
                for other_ip in all_ips:
                    print(f"  {other_ip}")
        except:
            pass
            
    except socket.herror:
        print(f"{t('error')}: {t('no_ptr', 'ui', 'No PTR record (reverse DNS)')}")
    except ValueError:
        print(f"{t('error')}: {t('invalid_ip', 'ui', 'Invalid IP address')}")
    except Exception as e:
        print(f"{t('error')}: {e}")

def show_my_ip(args):
    """Pokazuje publiczny IP"""
    _load_translations()
    
    print(f"{t('public_ip', 'ui', '🌐 Your public IP address:')}")
    print("=" * 40)
    
    services = [
        "https://api.ipify.org",
        "https://icanhazip.com", 
        "https://ident.me",
        "https://checkip.amazonaws.com"
    ]
    
    for service in services:
        try:
            response = requests.get(service, timeout=3)
            if response.status_code == 200:
                ip = response.text.strip()
                print(f"📡 {service.split('//')[1]}: {ip}")
                
                geo_response = requests.get(f"http://ip-api.com/json/{ip}", timeout=3)
                if geo_response.status_code == 200:
                    data = geo_response.json()
                    if data.get("status") == "success":
                        print(f"📍 {t('city', 'ui', 'City')}: {data.get('city', '')}, {data.get('country', '')}")
                        print(f"🏢 {t('isp', 'ui', 'ISP')}: {data.get('isp', '')}")
                        print(f"⏰ {t('timezone', 'ui', 'Timezone')}: {data.get('timezone', '')}")
                break
        except:
            continue
    else:
        print(f"{t('error')}: {t('service_error', 'ui', 'Failed to get IP')}")

def ip_calculator(args):
    """Kalkulator podsieci"""
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('ipcalc')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('ipcalc')}")
        return
    
    if len(args) == 1:
        cidr = args[0]
    else:
        ip = args[0]
        mask = args[1]
        cidr = f"{ip}/{mask}"
    
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        
        print(f"{t('subnet_calculator', 'ui', '🧮 Subnet calculator')}")
        print("=" * 60)
        
        print(f"📡 {t('network', 'ui', 'Network')}: {network.network_address}")
        print(f"🎭 {t('mask', 'ui', 'Mask')}: {network.netmask}")
        print(f"🔢 {t('cidr', 'ui', 'CIDR')}: /{network.prefixlen}")
        print(f"📍 {t('broadcast', 'ui', 'Broadcast')}: {network.broadcast_address}")
        print(f"🎯 {t('first_usable', 'ui', 'First usable')}: {list(network.hosts())[0] if network.num_addresses > 2 else 'N/A'}")
        print(f"🎯 {t('last_usable', 'ui', 'Last usable')}: {list(network.hosts())[-1] if network.num_addresses > 2 else 'N/A'}")
        print(f"🔢 {t('usable_hosts', 'ui', 'Usable hosts')}: {network.num_addresses - 2}")
        print(f"🌐 {t('address_range', 'ui', 'Address range')}: {network[0]} - {network[-1]}")
        
        print(f"\n{t('mask_details', 'ui', '🎭 Mask details')} {network.netmask}:")
        mask_int = int(network.netmask)
        ones = bin(mask_int).count("1")
        zeros = 32 - ones
        print(f"  {t('network_bits', 'ui', 'Network bits')}: {ones}")
        print(f"  {t('host_bits', 'ui', 'Host bits')}: {zeros}")
        print(f"  {t('decimal_value', 'ui', 'Decimal')}: {mask_int}")
        print(f"  {t('hex_value', 'ui', 'Hexadecimal')}: {hex(mask_int)}")
        
        if network.prefixlen <= 30:
            print(f"\n{t('possible_subnets', 'ui', '🔀 Possible subnets:')}")
            
            possible_masks = []
            if network.prefixlen <= 24:
                possible_masks.extend([25, 26, 27, 28, 29, 30])
            elif network.prefixlen <= 28:
                possible_masks.extend([29, 30])
            
            for new_prefix in possible_masks:
                if new_prefix > network.prefixlen:
                    subnets = list(network.subnets(new_prefix=new_prefix))
                    if len(subnets) <= 16:
                        print(f"\n  /{new_prefix}:")
                        print(f"    {t('subnets', 'ui', 'Subnets')}: {len(subnets)}")
                        print(f"    {t('hosts_per_subnet', 'ui', 'Hosts per subnet')}: {subnets[0].num_addresses - 2}")
        
        if len(args) == 1 and "/" in cidr:
            ip_part = cidr.split("/")[0]
            try:
                ip_obj = ipaddress.ip_address(ip_part)
                if ip_obj in network:
                    print(f"\n{t('success', 'ui', '✅ Success')} {ip_part} {t('belongs_to', 'ui', 'belongs to this network')}")
                else:
                    print(f"\n{t('error')} {ip_part} {t('not_belongs', 'ui', 'does NOT belong to this network')}")
            except:
                pass
                
    except Exception as e:
        print(f"{t('error')}: {e}")

def whois_lookup(args):
    """WHOIS lookup"""
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('whois')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('whois')}")
        return
    
    target = args[0]
    
    print(f"{t('whois_for', 'ui', '🔎 WHOIS lookup for:')} {target}")
    print("=" * 60)
    
    try:
        is_ip = False
        try:
            ipaddress.ip_address(target)
            is_ip = True
        except:
            pass
        
        if is_ip:
            response = requests.get(f"http://ip-api.com/json/{target}", timeout=5)
            if response.status_code == 200:
                data = response.json()
                
                if data.get("status") == "success":
                    print(f"🌍 {t('country', 'ui', 'Country')}: {data.get('country', 'N/A')}")
                    print(f"🏢 {t('organization', 'ui', 'Organization')}: {data.get('org', 'N/A')}")
                    print(f"📶 {t('isp', 'ui', 'ISP')}: {data.get('isp', 'N/A')}")
                    print(f"🔗 {t('as', 'ui', 'AS')}: {data.get('as', 'N/A')}")
                    
                    asn = data.get('as', '').split()[0] if data.get('as') else ''
                    if asn.startswith('AS'):
                        print(f"\n🌐 Regional registry:")
                        print(f"  RIPE: https://stat.ripe.net/{target}")
                        print(f"  ARIN: https://whois.arin.net/rest/ip/{target}")
                else:
                    print(f"{t('error')}: {t('service_error', 'ui', 'Service error')}")
            else:
                print(f"{t('error')}: {t('connection_error', 'ui', 'Connection error')}")
        
        else:
            import whois
            try:
                domain_info = whois.whois(target)
                
                print(f"🏷️ {t('domain', 'ui', 'Domain')}: {domain_info.domain_name}")
                print(f"📅 {t('registration_date', 'ui', 'Registration date')}: {domain_info.creation_date}")
                print(f"📅 {t('expiration_date', 'ui', 'Expiration date')}: {domain_info.expiration_date}")
                print(f"📅 {t('last_update', 'ui', 'Last update')}: {domain_info.updated_date}")
                
                if domain_info.registrar:
                    print(f"🏢 {t('registrar', 'ui', 'Registrar')}: {domain_info.registrar}")
                
                if domain_info.name_servers:
                    print(f"\n🌐 {t('ns_records', 'ui', 'Name Servers:')}")
                    for ns in domain_info.name_servers[:5]:
                        print(f"  {ns}")
                
                if domain_info.emails:
                    print(f"\n📧 {t('contact', 'ui', 'Contact:')}")
                    for email in domain_info.emails[:3]:
                        print(f"  {email}")
                
                print(f"\n{t('additional_info', 'ui', '🔗 Additional info:')}")
                print(f"  whois.domaintools.com/{target}")
                print(f"  who.is/whois/{target}")
                
            except Exception as e:
                print(f"{t('error')}: {e}")
                print(f"{t('install_tip', 'ui', '💡 Tip: Install python-whois')}")
    
    except Exception as e:
        print(f"{t('error')}: {e}")

def subnet_info(args):
    """Analiza podsieci"""
    _load_translations()
    
    if not args:
        print(f"{t('error')}: {t('usage', 'ui', 'Usage:')} {ut('subnet')}")
        print(f"  {t('example', 'ui', 'Example:')} {et('subnet')}")
        return
    
    cidr = args[0]
    
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        
        print(f"{t('subnet_analysis', 'ui', '🔬 Subnet analysis')}")
        print("=" * 60)
        
        print(f"🌐 {t('network', 'ui', 'Network')}: {network}")
        print(f"🎭 {t('mask', 'ui', 'Mask')}: {network.netmask} (/{network.prefixlen})")
        print(f"📍 {t('broadcast', 'ui', 'Broadcast')}: {network.broadcast_address}")
        print(f"🔢 {t('total_addresses_count', 'ui', 'Total addresses')}: {network.num_addresses}")
        print(f"🎯 {t('usable_hosts', 'ui', 'Usable hosts')}: {network.num_addresses - 2}")
        
        first_octet = int(str(network.network_address).split('.')[0])
        if first_octet < 128:
            print(f"📊 {t('network_class', 'ui', 'Network class')}: {t('class_a', 'ui', 'Class A')}")
        elif first_octet < 192:
            print(f"📊 {t('network_class', 'ui', 'Network class')}: {t('class_b', 'ui', 'Class B')}")
        elif first_octet < 224:
            print(f"📊 {t('network_class', 'ui', 'Network class')}: {t('class_c', 'ui', 'Class C')}")
        elif first_octet < 240:
            print(f"📊 {t('network_class', 'ui', 'Network class')}: {t('class_d', 'ui', 'Class D')}")
        else:
            print(f"📊 {t('network_class', 'ui', 'Network class')}: {t('class_e', 'ui', 'Class E')}")
        
        if network.is_private:
            print(f"🔒 {t('ip_range', 'ui', 'IP range')}: {t('private', 'ui', 'PRIVATE')}")
            print(f"   {t('rfc_1918', 'ui', 'RFC 1918')}")
        else:
            print(f"🌍 {t('ip_range', 'ui', 'IP range')}: {t('public', 'ui', 'PUBLIC')}")
        
        print(f"\n{t('possible_splits', 'ui', '🔀 Possible splits:')}")
        
        for new_prefix in range(network.prefixlen + 1, min(network.prefixlen + 5, 31)):
            try:
                subnets = list(network.subnets(new_prefix=new_prefix))
                if len(subnets) <= 32:
                    print(f"\n  /{new_prefix}:")
                    print(f"    {t('subnets', 'ui', 'Subnets')}: {len(subnets)}")
                    print(f"    {t('hosts_per_subnet', 'ui', 'Hosts per subnet')}: {subnets[0].num_addresses - 2}")
                    
                    if len(subnets) <= 8:
                        for i, subnet in enumerate(subnets[:4]):
                            print(f"    [{i}] {subnet.network_address}")
            
            except ValueError:
                break
        
        print(f"\n{t('example_addresses', 'ui', '🎯 Example addresses:')}")
        hosts = list(network.hosts())
        if hosts:
            for i in range(min(5, len(hosts))):
                print(f"  {t('host', 'ui', 'Host')} {i+1}: {hosts[i]}")
        
        print(f"\n{t('statistics', 'ui', '📈 Statistics:')}")
        total_ips = network.num_addresses
        usable = total_ips - 2 if total_ips > 2 else 0
        utilization = (usable / total_ips * 100) if total_ips > 0 else 0
        
        print(f"  {t('utilization', 'ui', 'Utilization')}: {utilization:.1f}%")
        print(f"  {t('waste', 'ui', 'Waste')}: {total_ips - usable} {t('addresses', 'ui', 'addresses')} ({100-utilization:.1f}%)")
        
    except Exception as e:
        print(f"{t('error')}: {e}")