"""
iplookup.py - Narzędzie do wyszukiwania informacji o adresach IP
Autor: HolyCMD Team
"""

import socket
import requests
import json
import ipaddress
from typing import Dict, Optional, Tuple
from datetime import datetime

def register():
    """Rejestracja komend pakietu"""
    return {
        "iplookup": ip_lookup,
        "ipinfo": ip_info,
        "ipgeo": ip_geolocation,
        "ipscan": ip_scan,
        "dnsresolve": dns_resolve,
        "reverse_dns": reverse_dns_lookup,
        "myip": show_my_ip,
        "ipcalc": ip_calculator,
        "whois": whois_lookup,
        "subnet": subnet_info
    }

def ip_lookup(args):
    """
    Główna komenda IP Lookup - pokazuje wszystkie dostępne opcje
    """
    print("""
🌐 HolyCMD IP Lookup Toolkit v1.0

Dostępne komendy:
  iplookup <ip/hostname>       - Podstawowe informacje o IP/hostname
  ipinfo <ip/hostname>         - Szczegółowe informacje o adresie
  ipgeo <ip/hostname>          - Geolokalizacja IP
  ipscan <network/mask>        - Skanowanie podsieci
  dnsresolve <hostname>        - Rozwiązywanie DNS
  reverse_dns <ip>             - Reverse DNS lookup
  myip                         - Pokaż swój publiczny IP
  ipcalc <ip/mask>             - Kalkulator podsieci
  whois <domain/ip>            - Informacje WHOIS (jeśli dostępne)
  subnet <cidr>                - Analiza podsieci

Przykłady:
  iplookup 8.8.8.8
  ipgeo google.com
  ipscan 192.168.1.0/24
  dnsresolve github.com
  myip
  ipcalc 192.168.1.0/24
  subnet 10.0.0.0/16
    """)

def ip_info(args):
    """
    Szczegółowe informacje o adresie IP lub hostname
    """
    if not args:
        print("❌ Użycie: ipinfo <ip/hostname>")
        print("   Przykład: ipinfo 8.8.8.8")
        print("   Przykład: ipinfo google.com")
        return
    
    target = args[0]
    
    print(f"🔍 Analizuję: {target}")
    print("=" * 50)
    
    try:
        # Sprawdź czy to IP czy hostname
        try:
            # Jeśli to IP
            ip_obj = ipaddress.ip_address(target)
            ip = target
            hostname = None
        except ValueError:
            # Jeśli to hostname - rozwiąż DNS
            try:
                ip = socket.gethostbyname(target)
                ip_obj = ipaddress.ip_address(ip)
                hostname = target
            except socket.gaierror:
                print(f"❌ Nie można rozwiązać hostname: {target}")
                return
        
        # Pobierz publiczne informacje o IP
        try:
            response = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
            if response.status_code == 200:
                data = response.json()
                
                print("📍 GEOLOKALIZACJA:")
                if data.get("status") == "success":
                    print(f"  Kraj: {data.get('country', 'N/A')}")
                    print(f"  Region: {data.get('regionName', 'N/A')}")
                    print(f"  Miasto: {data.get('city', 'N/A')}")
                    print(f"  Kod pocztowy: {data.get('zip', 'N/A')}")
                    print(f"  Szerokość geogr.: {data.get('lat', 'N/A')}")
                    print(f"  Długość geogr.: {data.get('lon', 'N/A')}")
                    print(f"  Strefa czasowa: {data.get('timezone', 'N/A')}")
                    print(f"  ISP: {data.get('isp', 'N/A')}")
                    print(f"  Organizacja: {data.get('org', 'N/A')}")
                    print(f"  AS: {data.get('as', 'N/A')}")
                else:
                    print("  (Nie udało się pobrać danych geolokalizacji)")
            else:
                print("  (Błąd połączenia z API geolokalizacji)")
        except:
            print("  (Nie udało się połączyć z serwisem geolokalizacji)")
        
        print("\n🔧 INFORMACJE TECHNICZNE:")
        print(f"  Adres IP: {ip}")
        if hostname:
            print(f"  Hostname: {hostname}")
        
        # Reverse DNS
        try:
            rev_dns = socket.gethostbyaddr(ip)[0]
            print(f"  Reverse DNS: {rev_dns}")
        except:
            print(f"  Reverse DNS: (brak)")
        
        print(f"  Typ IP: {'IPv4' if ip_obj.version == 4 else 'IPv6'}")
        
        # Sprawdź czy IP jest prywatne
        if ip_obj.is_private:
            print(f"  Zakres: PRYWATNY")
            if ip_obj.is_loopback:
                print(f"  Loopback: TAK")
            if ip_obj.is_link_local:
                print(f"  Link-local: TAK")
            if ip_obj.is_multicast:
                print(f"  Multicast: TAK")
        else:
            print(f"  Zakres: PUBLICZNY")
            if ip_obj.is_global:
                print(f"  Globalny: TAK")
            if ip_obj.is_reserved:
                print(f"  Zarezerwowany: TAK")
        
        # Sprawdź porty
        print("\n🧪 SPRAWDZENIE PORTÓW (podstawowe):")
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 3389, 8080]
        
        if ip_obj.is_private:
            print("  (Pomiń skanowanie dla IP prywatnych)")
        else:
            print("  Porty otwarte:")
            open_ports = []
            for port in common_ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    try:
                        service = socket.getservbyport(port)
                        open_ports.append((port, service))
                        print(f"    {port}/tcp - {service}")
                    except:
                        open_ports.append((port, "unknown"))
                        print(f"    {port}/tcp - unknown")
                sock.close()
            
            if not open_ports:
                print("    (brak otwartych portów)")
        
        print("\n🌐 BLACKLIST CHECK (podstawowy):")
        try:
            # Sprawdź na podstawowych blacklistach
            blacklists = [
                "zen.spamhaus.org",
                "bl.spamcop.net",
                "dnsbl.sorbs.net"
            ]
            
            for bl in blacklists:
                try:
                    query = ".".join(reversed(str(ip).split("."))) + f".{bl}"
                    socket.gethostbyname(query)
                    print(f"  ❌ Znaleziono na {bl}")
                except:
                    print(f"  ✓ Nie znaleziono na {bl}")
        except:
            print("  (Nie udało się sprawdzić blacklist)")
        
    except Exception as e:
        print(f"❌ Błąd: {e}")

def ip_geolocation(args):
    """
    Geolokalizacja adresu IP
    """
    if not args:
        print("❌ Użycie: ipgeo <ip/hostname>")
        return
    
    target = args[0]
    
    print(f"📍 Geolokalizacja dla: {target}")
    print("=" * 40)
    
    try:
        # Pobierz IP z hostname jeśli potrzeba
        try:
            ipaddress.ip_address(target)
            ip = target
        except ValueError:
            ip = socket.gethostbyname(target)
        
        # Użyj ip-api.com
        response = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("status") == "success":
                print(f"🌍 Kraj: {data.get('country', 'N/A')} ({data.get('countryCode', '')})")
                print(f"🏙️ Region: {data.get('regionName', 'N/A')} ({data.get('region', '')})")
                print(f"🏠 Miasto: {data.get('city', 'N/A')}")
                print(f"📮 Kod pocztowy: {data.get('zip', 'N/A')}")
                print(f"📡 Współrzędne: {data.get('lat', 'N/A')}, {data.get('lon', 'N/A')}")
                print(f"⏰ Strefa czasowa: {data.get('timezone', 'N/A')}")
                print(f"📶 ISP: {data.get('isp', 'N/A')}")
                print(f"🏢 Organizacja: {data.get('org', 'N/A')}")
                print(f"🔗 AS: {data.get('as', 'N/A')}")
                
                # Mapka (tekstowa)
                print(f"\n🗺️ Mapa:")
                lat = data.get('lat')
                lon = data.get('lon')
                if lat and lon:
                    print(f"  https://www.google.com/maps?q={lat},{lon}")
                    print(f"  https://www.openstreetmap.org/?mlat={lat}&mlon={lon}")
            else:
                print("❌ Nie udało się pobrać danych geolokalizacji")
                print(f"Błąd: {data.get('message', 'Nieznany błąd')}")
        else:
            print("❌ Błąd połączenia z serwisem geolokalizacji")
            
    except Exception as e:
        print(f"❌ Błąd: {e}")

def ip_scan(args):
    """
    Skanowanie podsieci
    """
    if not args:
        print("❌ Użycie: ipscan <network/mask>")
        print("   Przykład: ipscan 192.168.1.0/24")
        print("   Przykład: ipscan 10.0.0.0/255.255.255.0")
        return
    
    network_str = args[0]
    
    try:
        # Parsuj sieć
        if "/" in network_str:
            network = ipaddress.ip_network(network_str, strict=False)
        else:
            print("❌ Podaj maskę sieci (np. /24)")
            return
        
        print(f"🔍 Skanowanie sieci: {network}")
        print(f"   Zakres: {network.network_address} - {network.broadcast_address}")
        print(f"   Liczba hostów: {network.num_addresses - 2}")
        print("=" * 50)
        
        # Sprawdź tylko pierwsze 20 hostów (dla bezpieczeństwa)
        max_hosts = min(20, network.num_addresses)
        hosts_scanned = 0
        active_hosts = []
        
        for ip in network.hosts():
            if hosts_scanned >= max_hosts:
                print(f"\n⚠️  Przerwano po {max_hosts} hostach (limit bezpieczeństwa)")
                break
            
            hosts_scanned += 1
            ip_str = str(ip)
            
            print(f"  {ip_str}: ", end="", flush=True)
            
            # Ping ICMP (podstawowy)
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.3)
                result = sock.connect_ex((ip_str, 80))  # Sprawdź port 80
                
                if result == 0:
                    # Sprawdź czy host ma nazwę
                    try:
                        hostname = socket.gethostbyaddr(ip_str)[0]
                        print(f"✓ AKTYWNY ({hostname})")
                        active_hosts.append((ip_str, hostname))
                    except:
                        print("✓ AKTYWNY")
                        active_hosts.append((ip_str, None))
                else:
                    print("✗ NIEAKTYWNY")
                
                sock.close()
                
            except:
                print("✗ NIEAKTYWNY")
        
        # Podsumowanie
        print(f"\n📊 PODSUMOWANIE:")
        print(f"   Przeskanowano: {hosts_scanned} hostów")
        print(f"   Aktywnych: {len(active_hosts)} hostów")
        
        if active_hosts:
            print("\n🎯 AKTYWNE HOSTY:")
            for ip, hostname in active_hosts:
                if hostname:
                    print(f"   {ip} -> {hostname}")
                else:
                    print(f"   {ip}")
        
    except Exception as e:
        print(f"❌ Błąd: {e}")

def dns_resolve(args):
    """
    Rozwiązywanie DNS - wszystkie rekordy
    """
    if not args:
        print("❌ Użycie: dnsresolve <hostname>")
        print("   Przykład: dnsresolve google.com")
        return
    
    hostname = args[0]
    
    print(f"🔍 Rozwiązywanie DNS dla: {hostname}")
    print("=" * 50)
    
    try:
        # A record (IPv4)
        print("📡 Rekordy A (IPv4):")
        try:
            a_records = socket.gethostbyname_ex(hostname)[2]
            for ip in a_records:
                print(f"  {ip}")
        except:
            print("  (brak)")
        
        # IPv6 (jeśli dostępne)
        print("\n📡 Rekordy AAAA (IPv6):")
        try:
            aaaa_info = socket.getaddrinfo(hostname, None, socket.AF_INET6)
            ipv6_addrs = set()
            for info in aaaa_info:
                ipv6_addrs.add(info[4][0])
            
            for ip in ipv6_addrs:
                print(f"  {ip}")
        except:
            print("  (brak)")
        
        # MX records (jeśli dostępne)
        print("\n📨 Rekordy MX (Mail Exchange):")
        try:
            import dns.resolver
            mx_records = dns.resolver.resolve(hostname, 'MX')
            for mx in mx_records:
                print(f"  {mx.preference} {mx.exchange}")
        except:
            try:
                # Alternatywna metoda
                import subprocess
                result = subprocess.run(['nslookup', '-type=mx', hostname], 
                                      capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    if 'mail exchanger' in line:
                        print(f"  {line.strip()}")
            except:
                print("  (nie udało się pobrać MX)")
        
        # TXT records
        print("\n📝 Rekordy TXT:")
        try:
            txt_records = dns.resolver.resolve(hostname, 'TXT')
            for txt in txt_records:
                print(f"  {txt}")
        except:
            print("  (brak)")
        
        # Canonical name
        print("\n🏷️ Canonical Name (CNAME):")
        try:
            cname = dns.resolver.resolve(hostname, 'CNAME')
            for c in cname:
                print(f"  {c.target}")
        except:
            print("  (brak - to jest prawdopodobnie A record)")
        
        # NS records
        print("\n🌐 Name Servers (NS):")
        try:
            ns_records = dns.resolver.resolve(hostname, 'NS')
            for ns in ns_records:
                print(f"  {ns.target}")
        except:
            print("  (brak)")
        
        # SOA record
        print("\n⚙️ SOA Record:")
        try:
            soa = dns.resolver.resolve(hostname, 'SOA')
            for s in soa:
                print(f"  MNAME: {s.mname}")
                print(f"  RNAME: {s.rname}")
                print(f"  Serial: {s.serial}")
                print(f"  Refresh: {s.refresh}")
                print(f"  Retry: {s.retry}")
                print(f"  Expire: {s.expire}")
                print(f"  Minimum: {s.minimum}")
        except:
            print("  (brak)")
        
    except socket.gaierror:
        print("❌ Nie można rozwiązać hostname")
    except Exception as e:
        print(f"❌ Błąd: {e}")

def reverse_dns_lookup(args):
    """
    Reverse DNS lookup
    """
    if not args:
        print("❌ Użycie: reverse_dns <ip>")
        print("   Przykład: reverse_dns 8.8.8.8")
        return
    
    ip = args[0]
    
    print(f"🔄 Reverse DNS dla: {ip}")
    print("=" * 40)
    
    try:
        # Walidacja IP
        ipaddress.ip_address(ip)
        
        # Reverse lookup
        hostname, aliases, ips = socket.gethostbyaddr(ip)
        
        print(f"🏷️ Hostname: {hostname}")
        
        if aliases:
            print(f"📛 Aliases: {', '.join(aliases)}")
        
        print(f"📡 IPs: {', '.join(ips)}")
        
        # Dodatkowe info o hoście
        try:
            # Sprawdź czy to sama nazwa ma inne IP
            all_ips = socket.gethostbyname_ex(hostname)[2]
            if len(all_ips) > 1:
                print(f"\n🌐 Wszystkie IP dla {hostname}:")
                for other_ip in all_ips:
                    print(f"  {other_ip}")
        except:
            pass
            
    except socket.herror:
        print("❌ Brak wpisu PTR (reverse DNS)")
    except ValueError:
        print("❌ Nieprawidłowy adres IP")
    except Exception as e:
        print(f"❌ Błąd: {e}")

def show_my_ip(args):
    """
    Pokazuje twój publiczny adres IP
    """
    print("🌐 Twój publiczny adres IP:")
    print("=" * 40)
    
    services = [
        "https://api.ipify.org",
        "https://icanhazip.com",
        "https://ident.me",
        "https://checkip.amazonaws.com"
    ]
    
    for service in services:
        try:
            response = requests.get(service, timeout=3)
            if response.status_code == 200:
                ip = response.text.strip()
                print(f"📡 {service.split('//')[1]}: {ip}")
                
                # Pobierz dodatkowe info
                geo_response = requests.get(f"http://ip-api.com/json/{ip}", timeout=3)
                if geo_response.status_code == 200:
                    data = geo_response.json()
                    if data.get("status") == "success":
                        print(f"📍 Lokalizacja: {data.get('city', '')}, {data.get('country', '')}")
                        print(f"🏢 ISP: {data.get('isp', '')}")
                        print(f"⏰ Strefa czasowa: {data.get('timezone', '')}")
                break
        except:
            continue
    else:
        print("❌ Nie udało się pobrać publicznego IP")

def ip_calculator(args):
    """
    Kalkulator podsieci
    """
    if not args:
        print("❌ Użycie: ipcalc <ip/mask>")
        print("   Przykład: ipcalc 192.168.1.0/24")
        print("   Przykład: ipcalc 10.0.0.0 255.255.255.0")
        return
    
    if len(args) == 1:
        cidr = args[0]
    else:
        # Konwertuj maskę z IP/mask na CIDR
        ip = args[0]
        mask = args[1]
        cidr = f"{ip}/{mask}"
    
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        
        print("🧮 Kalkulator podsieci")
        print("=" * 60)
        
        print(f"📡 Adres sieci: {network.network_address}")
        print(f"🎭 Maska sieci: {network.netmask}")
        print(f"🔢 Notacja CIDR: /{network.prefixlen}")
        print(f"📍 Broadcast: {network.broadcast_address}")
        print(f"🎯 Pierwszy użyteczny: {list(network.hosts())[0] if network.num_addresses > 2 else 'N/A'}")
        print(f"🎯 Ostatni użyteczny: {list(network.hosts())[-1] if network.num_addresses > 2 else 'N/A'}")
        print(f"🔢 Liczba hostów: {network.num_addresses - 2}")
        print(f"🌐 Zakres adresów: {network[0]} - {network[-1]}")
        
        # Informacje o masce
        print(f"\n🎭 Szczegóły maski {network.netmask}:")
        mask_int = int(network.netmask)
        ones = bin(mask_int).count("1")
        zeros = 32 - ones
        print(f"  Bity sieci: {ones}")
        print(f"  Bity hosta: {zeros}")
        print(f"  Wartość dziesiętna: {mask_int}")
        print(f"  Wartość szesnastkowa: {hex(mask_int)}")
        
        # Podsieci (jeśli możliwe)
        if network.prefixlen <= 30:
            print(f"\n🔀 Możliwe podsieci:")
            
            # Pokazuj podziały dla popularnych masek
            possible_masks = []
            if network.prefixlen <= 24:
                possible_masks.extend([25, 26, 27, 28, 29, 30])
            elif network.prefixlen <= 28:
                possible_masks.extend([29, 30])
            
            for new_prefix in possible_masks:
                if new_prefix > network.prefixlen:
                    subnets = list(network.subnets(new_prefix=new_prefix))
                    if len(subnets) <= 16:  # Nie pokazuj za dużo
                        print(f"\n  /{new_prefix}:")
                        print(f"    Liczba podsieci: {len(subnets)}")
                        print(f"    Hosty na podsieć: {subnets[0].num_addresses - 2}")
        
        # Sprawdź czy IP należy do sieci
        if len(args) == 1 and "/" in cidr:
            ip_part = cidr.split("/")[0]
            try:
                ip_obj = ipaddress.ip_address(ip_part)
                if ip_obj in network:
                    print(f"\n✅ {ip_part} należy do tej sieci")
                else:
                    print(f"\n❌ {ip_part} NIE należy do tej sieci")
            except:
                pass
                
    except Exception as e:
        print(f"❌ Błąd: {e}")

def whois_lookup(args):
    """
    Podstawowy whois lookup
    """
    if not args:
        print("❌ Użycie: whois <domain/ip>")
        print("   Przykład: whois google.com")
        print("   Przykład: whois 8.8.8.8")
        return
    
    target = args[0]
    
    print(f"🔎 WHOIS lookup dla: {target}")
    print("=" * 60)
    
    try:
        # Sprawdź czy to IP czy domena
        is_ip = False
        try:
            ipaddress.ip_address(target)
            is_ip = True
        except:
            pass
        
        # Dla domen używamy whois
        # Dla IP używamy ip-api
        if is_ip:
            # WHOIS dla IP
            response = requests.get(f"http://ip-api.com/json/{target}", timeout=5)
            if response.status_code == 200:
                data = response.json()
                
                if data.get("status") == "success":
                    print(f"🌍 Kraj: {data.get('country', 'N/A')}")
                    print(f"🏢 Organizacja: {data.get('org', 'N/A')}")
                    print(f"📶 ISP: {data.get('isp', 'N/A')}")
                    print(f"🔗 AS: {data.get('as', 'N/A')}")
                    
                    # Dodatkowe info z RIPE/ARIN
                    print(f"\n🌐 Rejestr regionalny:")
                    asn = data.get('as', '').split()[0] if data.get('as') else ''
                    if asn.startswith('AS'):
                        print(f"  RIPE: https://stat.ripe.net/{target}")
                        print(f"  ARIN: https://whois.arin.net/rest/ip/{target}")
                else:
                    print("❌ Nie udało się pobrać informacji WHOIS")
            else:
                print("❌ Błąd połączenia")
        
        else:
            # WHOIS dla domeny (uproszczone)
            import whois
            try:
                domain_info = whois.whois(target)
                
                print(f"🏷️ Domen: {domain_info.domain_name}")
                print(f"📅 Data rejestracji: {domain_info.creation_date}")
                print(f"📅 Data wygaśnięcia: {domain_info.expiration_date}")
                print(f"📅 Ostatnia aktualizacja: {domain_info.updated_date}")
                
                if domain_info.registrar:
                    print(f"🏢 Registrar: {domain_info.registrar}")
                
                if domain_info.name_servers:
                    print(f"\n🌐 Name Servers:")
                    for ns in domain_info.name_servers[:5]:  # Limit do 5
                        print(f"  {ns}")
                
                if domain_info.emails:
                    print(f"\n📧 Kontakt:")
                    for email in domain_info.emails[:3]:  # Limit do 3
                        print(f"  {email}")
                
                # Dodatkowe linki
                print(f"\n🔗 Dodatkowe info:")
                print(f"  whois.domaintools.com/{target}")
                print(f"  who.is/whois/{target}")
                
            except Exception as e:
                print(f"❌ Błąd WHOIS: {e}")
                print("💡 Wskazówka: Zainstaluj 'python-whois' (pip install python-whois)")
    
    except Exception as e:
        print(f"❌ Błąd: {e}")

def subnet_info(args):
    """
    Analiza podsieci
    """
    if not args:
        print("❌ Użycie: subnet <cidr>")
        print("   Przykład: subnet 192.168.1.0/24")
        print("   Przykład: subnet 10.0.0.0/16")
        return
    
    cidr = args[0]
    
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        
        print("🔬 Analiza podsieci")
        print("=" * 60)
        
        print(f"🌐 Sieć: {network}")
        print(f"🎭 Maska: {network.netmask} (/{network.prefixlen})")
        print(f"📍 Broadcast: {network.broadcast_address}")
        print(f"🔢 Całkowita liczba adresów: {network.num_addresses}")
        print(f"🎯 Liczba hostów: {network.num_addresses - 2}")
        
        # Klasa sieci
        first_octet = int(str(network.network_address).split('.')[0])
        if first_octet < 128:
            print(f"📊 Klasa: A (1.0.0.0 - 126.255.255.255)")
        elif first_octet < 192:
            print(f"📊 Klasa: B (128.0.0.0 - 191.255.255.255)")
        elif first_octet < 224:
            print(f"📊 Klasa: C (192.0.0.0 - 223.255.255.255)")
        elif first_octet < 240:
            print(f"📊 Klasa: D (multicast)")
        else:
            print(f"📊 Klasa: E (eksperymentalna)")
        
        # Czy to private IP range
        if network.is_private:
            print(f"🔒 Zakres: PRYWATNY")
            print(f"   RFC 1918: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16")
        else:
            print(f"🌍 Zakres: PUBLICZNY")
        
        # Podsieci
        print(f"\n🔀 Możliwe podziały:")
        
        # Pokazuj tylko sensowne podziały
        for new_prefix in range(network.prefixlen + 1, min(network.prefixlen + 5, 31)):
            try:
                subnets = list(network.subnets(new_prefix=new_prefix))
                if len(subnets) <= 32:  # Ogranicz do rozsądnej liczby
                    print(f"\n  /{new_prefix}:")
                    print(f"    Podsieci: {len(subnets)}")
                    print(f"    Hosty/podsieć: {subnets[0].num_addresses - 2}")
                    
                    if len(subnets) <= 8:  # Pokazuj małe sieci
                        for i, subnet in enumerate(subnets[:4]):  # Tylko pierwsze 4
                            print(f"    [{i}] {subnet.network_address}")
            
            except ValueError:
                break
        
        # Przykładowe IP w sieci
        print(f"\n🎯 Przykładowe adresy:")
        hosts = list(network.hosts())
        if hosts:
            for i in range(min(5, len(hosts))):
                print(f"  Host {i+1}: {hosts[i]}")
        
        # Statystyki
        print(f"\n📈 Statystyki:")
        total_ips = network.num_addresses
        usable = total_ips - 2 if total_ips > 2 else 0
        utilization = (usable / total_ips * 100) if total_ips > 0 else 0
        
        print(f"  Wykorzystanie: {utilization:.1f}%")
        print(f"  Marnotrawstwo: {total_ips - usable} adresów ({100-utilization:.1f}%)")
        
    except Exception as e:
        print(f"❌ Błąd: {e}")