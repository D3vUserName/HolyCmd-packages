def register():
    return {
        "chess": play_chess,
        "chess_new": new_game,
        "chess_board": show_board
    }

def play_chess(args):
    print("♔ HolyCMD Chess v1.0")
    print("Use: chess_new to start new game")
    print("Use: chess_board to show board")

def new_game(args):
    print("♔ Starting new chess game...")
    print("White: ♙♙♙♙♙♙♙♙ ♖♘♗♕♔♗♘♖")
    print("Black: ♟♟♟♟♟♟♟♟ ♜♞♝♛♚♝♞♜")

def show_board(args):
    board = [
        "♜ ♞ ♝ ♛ ♚ ♝ ♞ ♜",
        "♟ ♟ ♟ ♟ ♟ ♟ ♟ ♟", 
        "・ ・ ・ ・ ・ ・ ・ ・",
        "・ ・ ・ ・ ・ ・ ・ ・",
        "・ ・ ・ ・ ・ ・ ・ ・",
        "・ ・ ・ ・ ・ ・ ・ ・",
        "♙ ♙ ♙ ♙ ♙ ♙ ♙ ♙",
        "♖ ♘ ♗ ♕ ♔ ♗ ♘ ♖"
    ]
    for row in board:
        print(row)